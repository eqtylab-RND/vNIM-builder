import asyncio
import base64
import inspect
import json
import logging
import os
import shutil
import tempfile
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional

from fastapi import APIRouter, FastAPI, Request
from starlette.datastructures import MutableHeaders
from starlette.responses import JSONResponse

from .config import Config
from ._timing import logger as timing_logger, timed_manifest_send
from ._notary import make_notary_rebind_hook, wait_for_notary_key_settle
from .manifest_writer import _ManifestWriter
from .model_source import (
    _base_model_id,
    _served_model_name,
    get_hf_path_from_name,
    locate_nim_snapshot_dir,
)

from eqty_sdk import (
    Context,
    DID,
    Model,
    Signer,
    SIGNER_ALGORITHMS,
    init,
    set_active_signer,
)

logger = logging.getLogger(__name__)

DEFAULT_VCOMP_CRT_NOTARY_URL = "http://docker.eqtylab.internal:8066"
DEFAULT_VCOMP_COCO_NOTARY_URL = "http://127.0.0.1:8066"

# Bootstrap state is stashed on the wrapped FastAPI app under this attribute so
# it is scoped per-application and survives Starlette's stack rebuild, instead
# of leaking across unrelated apps through a module global.
_BOOTSTRAP_ATTR = "_eqty_integrity_bootstrap"


# Endpoints explicitly opted out of attestation. Keyed on the *function object*,
# not its __name__: two unrelated routes can share a name (e.g. both called
# ``get``), so a name-keyed set would silently exclude the wrong one.
EXCLUDED_PATHS: set = set()


def eqty_exclude_from_integrity():
    def decorator(func):
        EXCLUDED_PATHS.add(func)
        return func
    return decorator


# This middleware is workload-agnostic: it hardcodes ONLY the paths it owns and
# never guesses the wrapped server's surface. The owned paths - the integrity
# read routes it injects and the notary's did-registration - are ALWAYS excluded
# (even under attest_all), because attesting them is self-referential and
# meaningless. Every server-specific infra/probe/metadata path (/v1/models,
# /health, /metrics, NIM's /v1/health/ready, a custom app's /status, ...) is
# declared by the operator via EQTY_MIDDLEWARE_EXCLUDE_PATHS (exact, or a
# trailing-'*' prefix); /tmp/api_logs growth is bounded regardless by log
# retention (Config.log_max_files). EQTY_MIDDLEWARE_ATTEST_ALL=true measures
# everything except the owned paths.
_EQTY_OWN_PREFIXES = ("/integrity", "/.well-known")


def _path_matches(path: str, pattern: str) -> bool:
    """Exact match, or a prefix match when the pattern ends in '*'."""
    if pattern.endswith("*"):
        return path.startswith(pattern[:-1])
    return path == pattern


def _path_excluded_from_integrity(path: Optional[str], config: Optional[Config] = None) -> bool:
    # config defaults to a fresh env read so the check is callable standalone and
    # never reads env at import time.
    if not path:
        return False
    if config is None:
        config = Config.from_env()
    # The middleware's own surface is isolated and unconditionally excluded.
    if any(path.startswith(pre) for pre in _EQTY_OWN_PREFIXES):
        return True
    if config.attest_all:
        return False
    return any(_path_matches(path, pat) for pat in config.exclude_paths)


class IntegrityFastAPI:
    def __init__(self, app: FastAPI, fastapi_app, log_directory: str = "request_logs",
                 model_cid: str = None,
                 delay_start: bool = False,
                 notary_url: Optional[str] = None,
                 config: Optional[Config] = None):
        self.app = app
        self._fastapi_app = fastapi_app
        self.model_cid = model_cid
        self._config = config or Config.from_env()
        logging.getLogger("eqty_middleware").setLevel(
            logging.DEBUG if self._config.debug else logging.INFO
        )
        # inspect.getsource is slow and blocking; cache it per endpoint.
        self._source_cache: Dict[Any, str] = {}

        # reuse the per-app bootstrap if this app's middleware stack is
        # rebuilt (Starlette restack / NIM startup) rather than re-running the
        # SDK init + model registration and re-registering a duplicate signer.
        bootstrap = getattr(fastapi_app, _BOOTSTRAP_ATTR, None)
        if bootstrap is not None:
            self.log_directory = bootstrap["log_directory"]
            self._model_manifest_path = bootstrap["_model_manifest_path"]
            self._base_ctx = bootstrap["_base_ctx"]
            self.eqty = bootstrap["eqty"]
            self._model_hashes = bootstrap["_model_hashes"]
            self._adapter_hashes = bootstrap["_adapter_hashes"]
            self._fixed_model = bootstrap["_fixed_model"]
            self._last_registered_model_name = bootstrap["_last_registered_model_name"]
            self._writer = bootstrap["_writer"]
            self._config = bootstrap["config"]
            set_active_signer(bootstrap["signer"])
            logger.info("IntegrityFastAPI: reusing existing context (already bootstrapped)")
            return

        self.log_directory = Path(log_directory)
        self.log_directory.mkdir(parents=True, exist_ok=True)
        self._model_hashes: Dict[str, Model] = {}
        # Adapter compositions (EQTY_MIDDLEWARE_ADAPTERS), kept separate from
        # _model_hashes so adapter names never shadow base-model resolution.
        self._adapter_hashes: Dict[str, Model] = {}
        self._fixed_model: Optional[str] = None
        # Name of the most recently registered model; the dispatch fallback label
        # when no per-request model can be resolved (was _KLUDGE_model_name).
        self._last_registered_model_name = ""

        self._model_manifest_path = self.log_directory / "base_model.manifest.json"
        self._writer = _ManifestWriter(
            self.log_directory, self._model_manifest_path, self._config,
        )

        eqty_notary = os.getenv('EQTY_NOTARY', None)
        # "vcomp" is the legacy alias for "vcomp-crt"; keep it working.
        if eqty_notary == "vcomp":
            eqty_notary = "vcomp-crt"

        if eqty_notary == "vcomp-coco":
            default_notary_url = DEFAULT_VCOMP_COCO_NOTARY_URL
        else:
            default_notary_url = DEFAULT_VCOMP_CRT_NOTARY_URL
        notary_url = notary_url or os.getenv('EQTY_NOTARY_URL') or default_notary_url

        os.makedirs(self._config.sdk_home, exist_ok=True)

        logger.info("Starting TEE Notary Init")

        # 2.x: every asset/computation is scoped to a Context. Establish a
        # base context that holds the model + its signing statements; each
        # request will create its own child-style context for isolation.
        self._base_ctx = Context.new("eqty-middleware")

        if eqty_notary in ("vcomp-crt", "vcomp-coco"):
            logger.info(f"Initializing TEE Notary Key ({eqty_notary}) against {notary_url}")
            self.eqty = (
                init(default_context=self._base_ctx, custom_dir=self._config.sdk_home)
                .set_store_all_blobs(True)
                .set_cid_ignore_rules(include_symlinks=True)
            )
            wait_for_notary_key_settle(notary_url)  # see _notary.py
            signer = Signer.vcomp_notary(
                notary_url,
                name="VCOMP Container Notary",
                _load_if_exists=True,
            )
            set_active_signer(signer)
            DID.from_signer(
                signer,
                name="VCOMP Container Notary",
                description="VCOMP signing key for integrity statements.",
            )
            # A co-located second notary client can rotate the key after this
            # bind; re-bind on the writer thread if it changes.
            self._writer.pre_write_hook = make_notary_rebind_hook(
                notary_url,
                signer_name="VCOMP Container Notary",
                did_name="VCOMP Container Notary",
                did_description="VCOMP signing key for integrity statements.",
            )
        else:
            logger.warning("Initializing Random Notary Key")
            logger.warning("Remember to backup your private key if you need to reference it again")
            self.eqty = (
                init(default_context=self._base_ctx, custom_dir=self._config.sdk_home)
                .set_store_all_blobs(True)
                .set_cid_ignore_rules(include_symlinks=True)
            )
            signer = Signer.new(
                SIGNER_ALGORITHMS.SECP256R1,
                name="Signing Key",
                _load_if_exists=True,
            )
            set_active_signer(signer)
            DID.from_signer(
                signer,
                name="Signing Key",
                description="Signing key for integrity statements.",
            )

        # Register /integrity/* unconditionally so the endpoints exist even when
        # delay_start defers model discovery.
        self._register_integrity_routes()

        if not delay_start:
            logger.info("Starting Model Initialization")
            self.initialize_model(None, None)
        else:
            logger.info("Delaying Model Initialization")

        setattr(fastapi_app, _BOOTSTRAP_ATTR, {
            "log_directory": self.log_directory,
            "_model_manifest_path": self._model_manifest_path,
            "_base_ctx": self._base_ctx,
            "eqty": self.eqty,
            "_model_hashes": self._model_hashes,
            "_adapter_hashes": self._adapter_hashes,
            "_fixed_model": self._fixed_model,
            "_last_registered_model_name": self._last_registered_model_name,
            "signer": signer,
            "_writer": self._writer,
            "config": self._config,
        })

    async def __call__(self, scope, receive, send):
        if scope["type"] == "http":
            if self._config.debug and scope.get("path", "").startswith("/integrity/manifest/"):
                send = timed_manifest_send(send, receive, scope)
            return await self._handle_http(scope, receive, send)
        if scope["type"] != "lifespan":
            return await self.app(scope, receive, send)

        async def send_wrapper(message):
            if message["type"] == "lifespan.shutdown.complete":
                try:
                    await asyncio.to_thread(self._writer.drain, self._config.drain_timeout)
                except Exception as e:
                    logger.error(f"attestation drain failed during shutdown: {e}")
            await send(message)

        await self.app(scope, receive, send_wrapper)

    def _model_kwargs(self):
        # 2.x: model signing is opt-in per asset. Only valid for SECP256R1 keys.
        return {"_enable_model_signing_signature": True} if self._config.enable_cosai else {}

    @staticmethod
    def _hashable_model_dir(model_path: str):
        """HF cache snapshots are symlink farms into blobs/; the SDK hashes a
        symlinked tree to a different CID than the same bytes as regular
        files, which would disconnect the served model from its published
        lineage. Mirror the tree with hardlinks to the resolved blobs (no
        data copy) and hash the mirror. Returns (path_to_hash, mirror_or_None)."""
        has_symlink = False
        for root, dirs, files in os.walk(model_path):
            if any(os.path.islink(os.path.join(root, n)) for n in files + dirs):
                has_symlink = True
                break
        if not has_symlink:
            return model_path, None

        def build_mirror(base_dir, link):
            mirror = tempfile.mkdtemp(prefix=".eqty-hash-", dir=base_dir)
            try:
                for root, dirs, files in os.walk(model_path, followlinks=True):
                    rel = os.path.relpath(root, model_path)
                    dst_root = mirror if rel == "." else os.path.join(mirror, rel)
                    os.makedirs(dst_root, exist_ok=True)
                    for f in files:
                        link(
                            os.path.realpath(os.path.join(root, f)),
                            os.path.join(dst_root, f),
                        )
                return mirror
            except OSError:
                shutil.rmtree(mirror, ignore_errors=True)
                raise

        # hardlinks next to the blobs are free; a read-only parent or
        # cross-device blobs fall back to a real copy in the system temp dir
        try:
            m = build_mirror(os.path.dirname(os.path.abspath(model_path)), os.link)
            return m, m
        except OSError as e:
            logger.warning(f"hardlink mirror failed ({e}); copying for hashing")
        try:
            m = build_mirror(None, shutil.copy2)
            return m, m
        except OSError as e:
            # a symlink-farm hash will NOT match the published weights CID,
            # so lineage joins break for this model - make that loud
            logger.error(
                f"cannot materialize symlinked model dir ({e}); "
                "hashing symlinks, CID will not match published lineage"
            )
            return model_path, None

    def _register_model(self, model_path: str, model_name: str, description: str):
        hash_path, mirror = self._hashable_model_dir(model_path)
        try:
            eq_model = Model.with_context(self._base_ctx).from_path(
                hash_path,
                name=model_name,
                description=description,
                _store=False,
                **self._model_kwargs(),
            )
        finally:
            if mirror:
                shutil.rmtree(mirror, ignore_errors=True)
        self._last_registered_model_name = model_name
        self._model_hashes[model_name] = eq_model
        logger.info("Generating complete, exporting base model manifest")
        self._export_base_manifest()
        logger.info(f"Base model manifest exported to {self._model_manifest_path}")
        return eq_model

    def _export_base_manifest(self):
        # atomic: the writer thread may read the base while it is being re-exported
        partial = self._model_manifest_path.with_name(f".{self._model_manifest_path.name}.partial")
        try:
            self._base_ctx.export(partial)
            os.replace(partial, self._model_manifest_path)
        finally:
            partial.unlink(missing_ok=True)

    def _register_adapters(self):
        """Register each EQTY_MIDDLEWARE_ADAPTERS dir as its own Model asset in
        the base context so per-request manifests can bind the adapter
        composition actually requested (see _resolve_adapter). A missing dir
        fails loudly: silently serving an unmeasured adapter is the exact gap
        this setting closes."""
        registered = False
        for name, path in self._config.adapters:
            if name in self._adapter_hashes:
                continue
            if not os.path.isdir(path):
                raise RuntimeError(
                    f"EQTY_MIDDLEWARE_ADAPTERS: adapter dir for '{name}' not found: {path}"
                )
            hash_path, mirror = self._hashable_model_dir(path)
            try:
                eq_adapter = Model.with_context(self._base_ctx).from_path(
                    hash_path,
                    name=name,
                    description=f"Adapter '{name}' served on top of the base model.",
                    _store=False,
                    **self._model_kwargs(),
                )
            finally:
                if mirror:
                    shutil.rmtree(mirror, ignore_errors=True)
            self._adapter_hashes[name] = eq_adapter
            registered = True
            logger.info(f"Registered adapter '{name}' from {path}")
        if registered:
            self._export_base_manifest()

    def initialize_model(self, model_path: str = None, model_name: str = None):
        logger.info("Initializing model")
        fastapi_app = self._fastapi_app
        # Before base-model discovery: discovery can bail early (no .state, no
        # snapshot dir yet), and the adapters must be measured regardless.
        self._register_adapters()

        if model_name is not None and model_path is None:
            model_path = get_hf_path_from_name(model_name)

        if model_path and os.path.exists(model_path):
            logger.info(f"Model path provided: {model_path}")
            model_name = model_name or os.path.basename(model_path)
            self._register_model(model_path, model_name, f"Model at {model_path}")
            self._fixed_model = model_name
        elif model_path:
            logger.warning(f"Model path provided but does not exist: {model_path}")

        if self._fixed_model is None:
            if hasattr(fastapi_app, "state"):
                logger.info("Found State in app")

                if hasattr(fastapi_app.state, "openai_serving_models"):
                    logger.info("Found OpenAI server")
                    model_name = _served_model_name(fastapi_app)
                    model_path = get_hf_path_from_name(model_name) if model_name else None
                    if model_path is None:
                        # HF cache is keyed by the real id, not the served-name alias
                        for real_id in (_base_model_id(fastapi_app), os.environ.get("MODEL_NAME")):
                            if real_id and real_id != model_name:
                                model_path = get_hf_path_from_name(real_id)
                                if model_path:
                                    break
                    if model_path is None:
                        # vLLM-direct NIMs (nemotron etc.) cache the model
                        # in the NIM NGC layout rather than the HF cache.
                        model_path = locate_nim_snapshot_dir(model_name) if model_name else None
                    if model_path is not None and model_name not in self._model_hashes:
                        self._register_model(model_path, model_name, model_name)
                    else:
                        logger.error("Open AI Check: Missing Model Path")
                else:
                    logger.info("Not OpenAI server, Checking NIM instead")
                    # os.environ.get returns None when unset (not ""), and many
                    # NIMs (e.g. qwen3.6 sglang) only set NIM_MODEL_NAME, never
                    # NIM_SERVED_MODEL_NAME. _served_model_name uses a falsy
                    # chain so we fall back whether the first var is missing or empty.
                    model_name = _served_model_name(fastapi_app)
                    if model_name:
                        snapshot_dir = locate_nim_snapshot_dir(model_name)
                        if snapshot_dir is None:
                            logger.warning(
                                "NIM CHECK: no snapshot dir found for "
                                f"{model_name}; skipping base model registration"
                            )
                        else:
                            logger.info(f"Found NIM model {model_name} at {snapshot_dir}")
                            self._register_model(snapshot_dir, model_name, model_name)
                    else:
                        logger.error("NIM CHECK: Missing model_name")
            else:
                logger.warning("FastAPI app has no .state; skipping model discovery")
                return
        # Only mark a fixed model if registration actually populated _model_hashes.
        # Otherwise dispatch would KeyError on a name with no hash (e.g. when
        # the NIM cache dir wasn't populated yet at init time).
        if model_name and model_name in self._model_hashes:
            self._fixed_model = model_name

    # Back-compat: apply-vllm-patch.py / vllm.patch call the misspelled
    # initalize_model() by walking the middleware stack. Keep the alias.
    initalize_model = initialize_model

    def _safe_log_path(self, request_id: str, suffix: str) -> Optional[Path]:
        """Resolve ``<log_dir>/<request_id><suffix>`` and refuse anything that
        escapes the log directory. ``request_id`` comes straight off the URL, so
        a value like ``../../etc/hostname`` must not read outside the dir."""
        base = self.log_directory.resolve()
        candidate = (base / f"{request_id}{suffix}").resolve()
        if not candidate.is_relative_to(base):
            return None
        return candidate

    def _register_integrity_routes(self):
        """Register /integrity/{logs,manifest} on the wrapped app. Called from
        __init__ unconditionally so the routes exist even when delay_start
        defers model discovery."""
        router = APIRouter(prefix="/integrity", tags=["integrity"])

        async def _serve_json(request_id: str, suffix: str):
            log_file = self._safe_log_path(request_id, suffix)
            # Uniform 404 for both "not found" and "path escapes dir" so the
            # endpoint never confirms files outside the log directory.
            timing = self._config.debug and suffix == ".manifest.json"
            if log_file is None or not log_file.exists():
                if timing:
                    timing_logger.debug(f"manifest GET {request_id!r} 404 {self._writer.pending_state(request_id)}")
                return JSONResponse(status_code=404, content={"detail": f"ID {request_id} not found"})
            try:
                t0 = time.time()
                content = await asyncio.to_thread(log_file.read_text)
                t1 = time.time()
                data = json.loads(content)
                if timing:
                    timing_logger.debug(
                        f"manifest GET {request_id!r} 200 read={t1 - t0:.3f}s parse={time.time() - t1:.3f}s"
                    )
                return data
            except Exception as e:
                return JSONResponse(status_code=500, content={"detail": f"Error reading file: {str(e)}"})

        @router.get("/logs/{request_id}", response_model=Dict[str, Any])
        @eqty_exclude_from_integrity()
        async def get_log_by_id(request_id: str):
            return await _serve_json(request_id, ".json")

        @router.get("/manifest/{request_id}", response_model=Dict[str, Any])
        @eqty_exclude_from_integrity()
        async def get_manifest_by_id(request_id: str):
            return await _serve_json(request_id, ".manifest.json")

        self._fastapi_app.include_router(router)

    def _endpoint_source(self, endpoint) -> str:
        """inspect.getsource for an endpoint, cached (slow + blocking)."""
        if endpoint is None:
            return "Unknown source"
        cached = self._source_cache.get(endpoint)
        if cached is None:
            try:
                cached = inspect.getsource(endpoint)
            except (OSError, TypeError) as e:
                logger.debug(f"getsource failed for {endpoint}: {e}")
                cached = "Unknown source"
            self._source_cache[endpoint] = cached
        return cached

    def _build_log_entry(self, request_id, request_data, response_data, source,
                         route_name, route_path, endpoint) -> dict:
        # One shape, built in one place, for both the streaming and buffered
        # branches.
        return {
            "request_id": request_id,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "request": request_data,
            "response": response_data,
            "route_source": source,
            "route_info": {
                "function_name": route_name,
                "path": route_path,
                "endpoint_module": endpoint.__module__ if endpoint else None,
            },
        }

    def _resolve_model(self, app):
        """(eq_model, model_cid, model_name) for the request's served model.

        Shares _served_model_name with init so dispatch can't drift from
        discovery. Only the CID *string* is later handed to the writer
        thread, never the live SDK object.
        """
        eq_model = None
        if self._fixed_model is not None and self._fixed_model in self._model_hashes:
            eq_model = self._model_hashes[self._fixed_model]
            logger.debug(f"Found model being used: {self._fixed_model} (FIXED)")
        else:
            current = _served_model_name(app)
            if current and current in self._model_hashes:
                eq_model = self._model_hashes[current]
                logger.debug(f"Found model being used: {current}")
            else:
                logger.debug("NO MODEL DEFINED!")
        model_cid = eq_model.cid if eq_model is not None else None
        model_name = self._fixed_model or self._last_registered_model_name or "Model"
        return eq_model, model_cid, model_name

    def _requested_model_name(self, request_data: dict) -> Optional[str]:
        """The request body's "model" field, across the capture modes of
        _process_body: parsed dict (json_body=true), base64-of-wire-bytes string
        (json_body=false), or the small-binary {"_base64": ...} stub. None when
        absent or undecodable."""
        body = request_data.get("body")
        try:
            if isinstance(body, dict):
                if body.get("_base64"):
                    body = json.loads(base64.b64decode(body["data"]))
                elif body.get("_truncated"):
                    return None
            elif isinstance(body, str):
                try:
                    body = json.loads(base64.b64decode(body, validate=True))
                except ValueError:
                    # json_body=true kept a non-JSON body as plain text
                    body = json.loads(body)
            else:
                return None
            model = body.get("model") if isinstance(body, dict) else None
            return model if isinstance(model, str) else None
        except Exception:
            return None

    def _resolve_adapter(self, request_data: dict):
        """(adapter_cid, adapter_name) when the request's "model" field names a
        registered adapter composition (vLLM --lora-modules style); (None, None)
        otherwise - a base-only request must never claim the adapter."""
        if not self._adapter_hashes:
            return None, None
        requested = self._requested_model_name(request_data)
        if requested is None:
            # Undecodable/absent model field while adapters are configured: the
            # manifest will omit the adapter even if one served the request.
            # Surface the underclaim; a non-matching NAME stays silent below -
            # that is an ordinary base-only request.
            logger.warning(
                "adapters configured but the request's model field could not "
                "be read; manifest will not claim an adapter"
            )
            return None, None
        eq_adapter = self._adapter_hashes.get(requested)
        if eq_adapter is None:
            return None, None
        return eq_adapter.cid, requested

    async def _handle_http(self, scope, receive, send):
        logger.debug("Starting dispatch")
        request = Request(scope, receive)
        route_path = request.url.path
        if _path_excluded_from_integrity(route_path, self._config):
            logger.debug("dispatch: excluded path, skipping attestation")
            return await self.app(scope, receive, send)

        request_id = str(uuid.uuid4())
        body = await request.body()
        request_data = await self._capture_request_data(request)
        body_sent = False

        async def replay_receive():
            nonlocal body_sent
            if body_sent:
                return await receive()
            body_sent = True
            return {"type": "http.request", "body": body, "more_body": False}

        state = {"attest": False, "status": None, "headers": None}
        chunks = []

        async def send_wrapper(message):
            if message["type"] == "http.response.start":
                # starlette's router sets scope["endpoint"] before http.response.start
                if scope.get("endpoint") in EXCLUDED_PATHS:
                    logger.debug("dispatch: excluded path, skipping attestation")
                    return await send(message)
                headers = MutableHeaders(scope=message)
                headers["X-EQTY-Request-ID"] = request_id
                headers["Access-Control-Expose-Headers"] = "X-EQTY-Request-ID"
                state["status"] = message["status"]
                state["headers"] = dict(headers)
                state["attest"] = 200 <= message["status"] < 300
                return await send(message)
            if message["type"] != "http.response.body" or not state["attest"]:
                return await send(message)
            chunks.append(message.get("body", b""))
            await send(message)
            if not message.get("more_body", False):
                state["attest"] = False
                self._enqueue_response(request.app, request_id, request_data, scope.get("endpoint"),
                                       route_path, state, b''.join(chunks))

        await self.app(scope, replay_receive, send_wrapper)

    def _enqueue_response(self, app, request_id, request_data, endpoint, route_path,
                          state, combined_body):
        route_name = endpoint.__name__ if endpoint else None
        _, model_cid, model_name = self._resolve_model(app)
        try:
            response_body = self._process_body(combined_body)
        except Exception as e:
            logger.warning(f"Failed to process streaming chunks: {str(e)}")
            response_body = "<failed_to_process_streaming_content>"

        response_data = {
            "status_code": state["status"],
            "headers": state["headers"],
            "body": response_body,
        }

        adapter_cid, adapter_name = self._resolve_adapter(request_data)
        log_entry = self._build_log_entry(
            request_id, request_data, response_data, self._endpoint_source(endpoint),
            route_name, route_path, endpoint,
        )
        self._writer.enqueue(
            request_id, log_entry, model_cid, model_name,
            adapter_cid, adapter_name,
        )

    async def _capture_request_data(self, request: Request) -> dict:
        headers = dict(request.headers)
        path_params = dict(request.path_params)
        query_params = dict(request.query_params)
        endpoint = request.scope.get("endpoint")
        endpoint_name = endpoint.__name__ if endpoint else None
        endpoint_module = endpoint.__module__ if endpoint else None
        body_bytes = await request.body()
        decoded_body = self._process_body(body_bytes)

        return {
            "method": request.method,
            "url": str(request.url),
            "headers": headers,
            "path_params": path_params,
            "query_params": query_params,
            "body": decoded_body,
            "endpoint": {"name": endpoint_name, "module": endpoint_module},
        }

    def _process_body(self, combined_body: bytes) -> Any:
        # bound what we retain so an oversize body can't OOM the worker.
        cap = self._config.max_body_bytes
        if cap and len(combined_body) > cap:
            logger.warning(
                f"body of {len(combined_body)} bytes exceeds "
                f"EQTY_MIDDLEWARE_MAX_BODY_BYTES={cap}; storing size-only placeholder"
            )
            return {"_truncated": True, "size": len(combined_body)}
        if not self._config.json_body:
            # exact wire bytes, base64-wrapped, so the body CID matches the raw payload
            return base64.b64encode(combined_body).decode('ascii')
        try:
            decoded_body = combined_body.decode('utf-8')
            try:
                return json.loads(decoded_body)
            except json.JSONDecodeError:
                return decoded_body
        except UnicodeDecodeError:
            if len(combined_body) < 2000:
                return {
                    "_base64": True,
                    "data": base64.b64encode(combined_body).decode('ascii'),
                    "size": len(combined_body),
                }
            return f"<binary data: {len(combined_body)} bytes>"
