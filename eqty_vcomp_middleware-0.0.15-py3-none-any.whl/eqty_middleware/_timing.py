"""EQTY_DEBUG manifest GET send timing, logged on eqty_middleware.timing (the host attaches the handler)."""
import asyncio
import logging
import time

logger = logging.getLogger("eqty_middleware.timing")

# uvicorn awaits flow-control drain before each body write, so per-chunk sends
# track the real socket progress; one 13 MB send returns as soon as it is buffered.
_CHUNK = 64 * 1024


def timed_manifest_send(send, receive, scope):
    """ASGI send wrapper for GET /integrity/manifest/{id}: logs when headers went out and when the last body byte was accepted by the socket."""
    t0 = time.time()
    request_id = scope.get("path", "").rsplit("/", 1)[-1]
    headers = {k.decode("latin-1"): v.decode("latin-1") for k, v in scope.get("headers", [])}
    state = {"status": None, "start": t0, "sent": 0, "max_wait": 0.0, "watch": None}

    async def wrapped(message):
        if message["type"] == "http.response.start":
            state["status"] = message["status"]
            await send(message)
            if message["status"] != 200:
                # _serve_json already logged the 404/500; pass the small body straight through
                state["logged"] = True
                return
            state["start"] = time.time()
            # uvicorn drops sends after a disconnect without raising; the request body is
            # consumed by now, so the next receive() only returns on disconnect or completion
            state["watch"] = asyncio.ensure_future(receive())
            return
        if message["type"] != "http.response.body" or state.get("logged"):
            await send(message)
            return
        body = message.get("body", b"")
        more = message.get("more_body", False)
        view = memoryview(body)
        outcome = "sent"
        try:
            for i in range(0, max(len(body), 1), _CHUNK):
                piece = bytes(view[i:i + _CHUNK])
                t = time.time()
                await send({"type": "http.response.body", "body": piece,
                            "more_body": more or i + _CHUNK < len(body)})
                state["max_wait"] = max(state["max_wait"], time.time() - t)
                state["sent"] += len(piece)
                watch = state["watch"]
                if watch is not None and watch.done() and not watch.cancelled() and not watch.exception() \
                        and watch.result().get("type") == "http.disconnect" and i + _CHUNK < len(body):
                    outcome, more = "aborted(client disconnected)", False
                    break
        except BaseException as e:
            # a client that gives up mid-body (e.g. a timeout) is the case being chased; log it too
            outcome = f"aborted({type(e).__name__})"
            more = False
            raise
        finally:
            if not more:
                watch = state["watch"]
                if watch is not None:
                    if not watch.done():
                        watch.cancel()
                    elif not watch.cancelled():
                        watch.exception()  # retrieved, so asyncio doesn't log it as never retrieved
                state["logged"] = True
                _log_send(request_id, outcome, state, t0, scope, headers)

    return wrapped


def _log_send(request_id, outcome, state, t0, scope, headers):
    now = time.time()
    logger.debug(
        f"manifest GET {request_id!r} {outcome} status={state['status']} bytes={state['sent']} "
        f"headers_out=+{state['start'] - t0:.3f}s body_done=+{now - t0:.3f}s "
        f"send={now - state['start']:.3f}s max_chunk_wait={state['max_wait']:.3f}s "
        f"client={scope.get('client')} ua={headers.get('user-agent', '-')!r} "
        f"xff={headers.get('x-forwarded-for', '-')!r}"
    )
