import os
from dataclasses import dataclass


@dataclass(frozen=True)
class Config:
    """All EQTY_* tunables, read once when the middleware is constructed.

    Reading env here (via :meth:`from_env`, called from ``__init__``) rather than
    at module import keeps the module importable without the environment in
    place and lets a per-worker fork change behaviour before constructing the
    middleware.
    """

    debug: bool = False
    # Per-side header capture, opt-in: headers are dropped from the manifest by
    # default. Replaces the single, inverted EQTY_MIDDLEWARE_NOHEADERHASH.
    include_request_header: bool = False
    include_response_header: bool = False
    # CoSAI per-model signing signatures (SECP256R1 keys only); on by default.
    enable_cosai: bool = True
    # Body capture representation. json_body=False (default) stores the body as
    # base64 of the *exact wire bytes*, so the CID binds what was actually
    # transmitted with no parse/re-serialize round-trip. True parses bodies
    # (utf-8 -> JSON object, falling back to raw text / base64) before hashing,
    # which can desync the CID from the raw payload: a parsed-then-reserialized
    # JSON body no longer matches the bytes the sender sent.
    json_body: bool = False
    # isolate_body=True (default) breaks each request/response body out of the
    # Request/Response document into its OWN content-addressed node, wired into
    # the Computation as a separate input/output. Identical bodies across requests
    # then share one CID, so the lineage graph is composable on body content
    # alone. Size-only/opaque placeholders are never isolated (see manifest_writer).
    isolate_body: bool = True
    # Attest every dispatched route, including infra/health probes (legacy behavior).
    attest_all: bool = False
    # Cap the number of retained *.manifest.json files; once reached, the oldest
    # are pruned on each write (base_model is never pruned). This is the
    # workload-agnostic bound on /tmp/api_logs growth - it holds on any app
    # regardless of which paths are excluded. 0 = unlimited.
    log_max_files: int = 1000
    # Seconds to spend draining pending attestation writes on graceful shutdown.
    drain_timeout: float = 25.0
    # 0 = unbounded, as queue.Queue(maxsize=0)
    queue_max: int = 1000
    # Largest request/response body (bytes) captured verbatim into a manifest;
    # over this a size-only placeholder is stored so a huge upload/generation
    # can't OOM the worker. Default is far above real LLM I/O (KBs),
    # so normal attestation content is unaffected. 0 disables the cap.
    max_body_bytes: int = 25 * 1024 * 1024
    # SDK working dir; was hardcoded to /tmp/EQTYSDK.
    sdk_home: str = "/tmp/EQTYSDK"
    # Operator paths to exclude from attestation: each is an exact path or a
    # trailing-'*' prefix (e.g. "/v1/health/*"). The middleware hardcodes only
    # its own routes; the wrapped server's infra/probe paths are declared here.
    exclude_paths: frozenset = frozenset()
    # (served-name, adapter-dir) pairs from EQTY_MIDDLEWARE_ADAPTERS ("name=/dir,..."),
    # as vLLM's --lora-modules; a request naming one gets its CID as a Computation input
    adapters: tuple = ()

    @classmethod
    def from_env(cls) -> "Config":
        def _b(name: str, default: str = "false") -> bool:
            return os.getenv(name, default).lower() == "true"

        def _adapters(raw: str) -> tuple:
            pairs = []
            for entry in raw.split(","):
                entry = entry.strip()
                if not entry:
                    continue
                name, sep, path = entry.partition("=")
                # Fail fast: a typo'd entry would silently serve an unmeasured
                # adapter, which is the exact gap this setting closes.
                if not sep or not name.strip() or not path.strip():
                    raise ValueError(
                        f"EQTY_MIDDLEWARE_ADAPTERS entry {entry!r} is not '<name>=<path>'"
                    )
                pairs.append((name.strip(), path.strip()))
            return tuple(pairs)

        # ENABLE_COSAI is the canonical name (default true). USE_COSAI / USE_COSIA
        # (the latter a historical typo) are the prior names, kept only for
        # back-compat and honored when the new var is unset; they will be removed
        # soon - migrate deployments to ENABLE_COSAI.
        cosai = os.getenv("EQTY_MIDDLEWARE_ENABLE_COSAI")
        if cosai is None:
            cosai = os.getenv("EQTY_MIDDLEWARE_USE_COSAI") or os.getenv(
                "EQTY_MIDDLEWARE_USE_COSIA"
            )

        return cls(
            debug=_b("EQTY_DEBUG"),
            include_request_header=_b("EQTY_MIDDLEWARE_INCLUDE_REQUEST_HEADER"),
            include_response_header=_b("EQTY_MIDDLEWARE_INCLUDE_RESPONSE_HEADER"),
            enable_cosai=(cosai or "true").lower() == "true",
            json_body=_b("EQTY_MIDDLEWARE_JSON_BODY", "false"),
            isolate_body=_b("EQTY_MIDDLEWARE_ISOLATE_BODY", "true"),
            attest_all=_b("EQTY_MIDDLEWARE_ATTEST_ALL"),
            log_max_files=int(os.getenv("EQTY_MIDDLEWARE_LOG_MAX_FILES", "1000") or "1000"),
            drain_timeout=float(os.getenv("EQTY_MIDDLEWARE_DRAIN_TIMEOUT", "25") or 25),
            queue_max=int(os.getenv("EQTY_MIDDLEWARE_QUEUE_MAX", "1000") or "1000"),
            max_body_bytes=int(
                os.getenv("EQTY_MIDDLEWARE_MAX_BODY_BYTES", str(25 * 1024 * 1024)) or 0
            ),
            sdk_home=os.getenv("EQTY_SDK_HOME", "/tmp/EQTYSDK"),
            exclude_paths=frozenset(
                p.strip()
                for p in os.getenv("EQTY_MIDDLEWARE_EXCLUDE_PATHS", "").split(",")
                if p.strip()
            ),
            adapters=_adapters(os.getenv("EQTY_MIDDLEWARE_ADAPTERS", "")),
        )
