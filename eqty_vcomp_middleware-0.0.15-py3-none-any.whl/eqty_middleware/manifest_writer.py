"""Off-event-loop attestation-manifest writer and the temp-file asset helpers
it relies on. Workload-agnostic: it only consumes plain log-entry dicts plus a
model CID *string* handed across the thread boundary."""
import base64
import copy
import json
import logging
import os
import queue
import shutil
import tempfile
import threading
import time
import traceback
from pathlib import Path

from .config import Config
from ._timing import logger as timing_logger

from eqty_sdk import (
    Code,
    Computation,
    Context,
    Document,
    Model,
)

logger = logging.getLogger(__name__)


def _document_from_collection(collection: dict, name: str, ctx: Context):
    """Pack {filename: body} into a temp dir and register as a Document in ctx."""
    base = Path(tempfile.mkdtemp(prefix="tempfiles_"))
    try:
        for entry, body in collection.items():
            # basename guards against separators in keys escaping `base`.
            path = base.joinpath(f"{os.path.basename(str(entry))}.txt")
            if isinstance(body, bytes):
                path.write_bytes(body)
            else:
                path.write_text(f"{body}", encoding="utf-8")

        eq_result = Document.with_context(ctx).from_path(base, name=name)
        logger.debug(f"Iroh collection CID: {eq_result.cid}")
        return eq_result
    finally:
        # the SDK has hashed the dir by now; don't leak a temp dir per call.
        shutil.rmtree(base, ignore_errors=True)


def _serialize_for_hashing(value) -> bytes:
    """Deterministic bytes for an in-memory value, mirroring the SDK's own
    primitive handling (str -> utf-8, dict/list -> json). Used so we never reach
    from_object()'s pickle fallback, which embeds non-deterministic state and
    would desync the CID between the server and the agent harness."""
    if isinstance(value, bytes):
        return value
    if isinstance(value, str):
        return value.encode("utf-8")
    return json.dumps(value).encode("utf-8")


def _document_from_base64(b64_data: str, name: str, ctx: Context):
    """Decode a base64 carrier to its exact bytes in a unique temp file and
    register it as a Document. Gives an isolated body node a CID over the raw
    wire bytes (the json_body=False carrier), not over the base64 text. from_path
    keeps it deterministic; mkstemp avoids traversal and concurrent clobber."""
    suffix = os.path.basename(name) or "body"
    fd, file_path = tempfile.mkstemp(prefix="eqty_", suffix=f"_{suffix}")
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(base64.b64decode(b64_data))
        return Document.with_context(ctx).from_path(file_path, name=name)
    finally:
        try:
            os.remove(file_path)  # don't leak the temp file
        except OSError:
            pass


def _is_body_placeholder(body) -> bool:
    """True for the size-only / opaque stubs _process_body emits for an over-cap
    body ({"_truncated": ...}) or an undecodable large binary ("<binary data: N
    bytes>"). These carry no reproducible content, so isolating them as a node
    would collapse distinct bodies onto one CID - keep them inline instead."""
    if isinstance(body, dict) and body.get("_truncated"):
        return True
    if isinstance(body, str) and body.startswith("<binary data:"):
        return True
    return False


def _asset_from_value(asset_cls, value, name: str, ctx: Context):
    """Register `value` as an `asset_cls` with a stable, file-derived CID.

    Writes the deterministic serialization to a unique temp file and uses
    from_path() rather than from_object() (see _serialize_for_hashing). mkstemp
    gives a private, non-colliding file so concurrent writes never clobber."""
    fd, file_path = tempfile.mkstemp(prefix="eqty_")
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(_serialize_for_hashing(value))
        return asset_cls.with_context(ctx).from_path(file_path, name=name)
    finally:
        try:
            os.remove(file_path)  # don't leak the temp file
        except OSError:
            pass


def _merge_manifests(base: dict, req: dict) -> dict:
    """Union of two exported manifests, as integrity's manifest::merge_async:
    contexts, statements (by id) and blobs (by CID) are maps, so the result
    equals exporting a context that imported `base` (version is the export's)."""
    merged = {"version": req["version"]}
    for key in ("contexts", "statements", "blobs"):
        merged[key] = {**base.get(key, {}), **req.get(key, {})}
    if "anchors" in base or "anchors" in req:
        merged["anchors"] = base.get("anchors", []) + req.get("anchors", [])
    return merged


class _Job:
    """A generic callable work-item for the writer thread (see ``submit``)."""

    def __init__(self, fn):
        self.fn = fn


def _timing_line(queued_at, marks) -> str:
    """One line of stage durations; a stage missing from marks failed or was skipped."""
    parts, prev = [], queued_at
    for stage, label in (("dequeued", "queue_wait"), ("hook", "hook"), ("statements", "statements_signed"),
                         ("export", "export"), ("merge", "merge_write"), ("ready", "ready"),
                         ("cleanup", "cleanup"), ("pruned", "prune")):
        if stage not in marks:
            parts.append(f"{label}=FAILED")
            break
        if stage == "ready":
            parts.append(f"ready_since_queued={marks[stage] - queued_at:.3f}s")
        else:
            parts.append(f"{label}={marks[stage] - prev:.3f}s")
        prev = marks[stage]
    if "bytes" in marks:
        parts.append(f"bytes={marks['bytes']}")
    return ("written " if "ready" in marks else "failed ") + " ".join(parts)


class _ManifestWriter:
    """Serialized, off-event-loop writer for per-request attestation manifests.

    The manifest export calls into the eqty-sdk indexer, which does blocking
    sqlite work (seconds per request). Running that on the asyncio event loop
    (the old ``asyncio.create_task(self._write_log_file(...))``) blocked the loop
 and, because the tasks were unreferenced and never awaited, dropped every
    in-flight attestation on shutdown. Here all SDK work happens on a single
    dedicated thread (consistent thread affinity for the SDK's sqlite handles),
    fed by a queue; only plain data + the model CID *string* crosses the thread
    boundary (never a live SDK object). ``drain()`` flushes the backlog on a
    graceful lifespan shutdown.
    """

    _STOP = object()

    def __init__(self, log_directory: Path, model_manifest_path: Path, config: Config):
        self.log_directory = log_directory
        self._model_manifest_path = model_manifest_path
        self._config = config
        self.max_files = config.log_max_files
        # Optional zero-arg callable run on this thread before each signed write
        # (e.g. the notary re-bind hook); set after construction.
        self.pre_write_hook = None
        self._base_cache = None
        # request_id -> (state, queued_at) while a manifest is pending; read by the GET 404 timing line
        self._pending = {}
        # nothing is mid-write before the thread starts, so any partial is left by a killed process
        for orphan in self.log_directory.glob(".*.partial"):
            orphan.unlink(missing_ok=True)
        self._queue: "queue.Queue" = queue.Queue(maxsize=config.queue_max)
        self.dropped = 0
        self._dropped_lock = threading.Lock()
        self._thread = threading.Thread(
            target=self._run, name="eqty-manifest-writer", daemon=True
        )
        self._thread.start()

    def _run_pre_write_hook(self):
        if self.pre_write_hook is None:
            return
        try:
            self.pre_write_hook()
        except Exception as e:
            logger.error(f"pre_write_hook failed (continuing with current DID): {e}")

    @property
    def depth(self) -> int:
        return self._queue.qsize()

    def _put(self, item, label) -> bool:
        try:
            self._queue.put_nowait(item)
            return True
        except queue.Full:
            with self._dropped_lock:
                self.dropped += 1
                dropped = self.dropped
            logger.error(
                f"Attestation queue full (depth={self.depth}, max={self._queue.maxsize}): "
                f"dropped {label}, {dropped} dropped total"
            )
            return False

    def enqueue(self, request_id, log_entry, model_cid, model_name,
                adapter_cid=None, adapter_name=None):
        if self._config.debug:
            self._pending[request_id] = ("queued", time.time())
        if not self._put(
            (request_id, log_entry, model_cid, model_name, adapter_cid, adapter_name), request_id
        ):
            # a dropped attestation is never written, so the GET 404 line must not report it queued
            self._pending.pop(request_id, None)
            return
        if self._config.debug:
            timing_logger.debug(f"manifest {request_id} queued depth={self._queue.qsize()}")

    def pending_state(self, request_id) -> str:
        entry = self._pending.get(request_id)
        if entry is None:
            return "unknown"
        return f"{entry[0]} queued_ago={time.time() - entry[1]:.3f}s"

    def submit(self, fn):
        """Run an arbitrary SDK-building callable on this writer thread, for
        callers that build non-request/response manifests (e.g. the guardrails
        exchange manifest). Unused by the request/response path."""
        self._put(_Job(fn), "submitted job")

    def drain(self, timeout: float = 25.0):
        """Block until the backlog is written or ``timeout`` elapses (graceful shutdown)."""
        deadline = time.monotonic() + timeout
        while self._queue.unfinished_tasks > 0 and time.monotonic() < deadline:
            time.sleep(0.1)
        remaining = self._queue.unfinished_tasks
        if remaining:
            logger.error(
                f"Shutdown drain timed out: {remaining} attestation(s) unwritten after {timeout}s"
                f" ({self.dropped} dropped on full queue)"
            )
        else:
            logger.info(
                "Shutdown drain complete: all pending attestations written"
                f" ({self.dropped} dropped on full queue)"
            )

    def _run(self):
        while True:
            item = self._queue.get()
            if item is self._STOP:
                self._queue.task_done()
                return
            if isinstance(item, _Job):
                try:
                    self._run_pre_write_hook()
                    item.fn()
                except Exception as e:
                    traceback.print_exc()
                    logger.error(f"submitted manifest job failed: {e}")
                finally:
                    self._queue.task_done()
                continue
            request_id, log_entry, model_cid, model_name, adapter_cid, adapter_name = item
            queued_at = self._pending.get(request_id, (None, time.time()))[1]
            if self._config.debug:
                self._pending[request_id] = ("writing", queued_at)
            marks = {"dequeued": time.time()}
            try:
                self._run_pre_write_hook()
                marks["hook"] = time.time()
                self._write_sync(
                    request_id, log_entry, model_cid, model_name,
                    adapter_cid, adapter_name, marks,
                )
            except Exception as e:
                traceback.print_exc()
                # a failed attestation is a security-relevant event, not info.
                logger.error(f"Failed to write manifest for {request_id}: {e}")
            finally:
                self._queue.task_done()
                self._pending.pop(request_id, None)
                self._prune()
                if self._config.debug:
                    marks["pruned"] = time.time()
                    timing_logger.debug(f"manifest {request_id} {_timing_line(queued_at, marks)}")

    def _base_manifest(self):
        """Parsed base_model.manifest.json, re-read only when the file changes.
        Folded into each request manifest by _merge_manifests instead of being
        imported into every request context (re-parsing and re-indexing ~13 MB
        per request). A base that won't parse fails the write, as the import did."""
        try:
            st = self._model_manifest_path.stat()
        except FileNotFoundError:
            return None
        key = (st.st_mtime_ns, st.st_size)
        if self._base_cache is None or self._base_cache[0] != key:
            self._base_cache = (key, json.loads(self._model_manifest_path.read_bytes()))
        return self._base_cache[1]

    def _prune(self):
        if self.max_files <= 0:
            return
        try:
            files = sorted(
                self.log_directory.glob("*.manifest.json"),
                key=lambda p: p.stat().st_mtime,
            )
            for old in files[:-self.max_files]:
                if old.name == "base_model.manifest.json":
                    continue
                old.unlink(missing_ok=True)
        except Exception as e:
            logger.warning(f"manifest retention prune failed: {e}")

    def _isolate_body(self, container: dict, name: str, ctx):
        """When isolate_body is on and the body is real content, pop it from the
        envelope and register it as its own content-addressed node; return that
        node (else None, leaving the body inline in `container`)."""
        if not self._config.isolate_body:
            return None
        body = container.get("body")
        if not body or _is_body_placeholder(body):
            return None
        container.pop("body", None)
        # CID an isolated *binary* body over its raw wire bytes regardless of mode,
        # so a verifier reproduces it by hashing the body - not by reconstructing a
        # base64 wrapper. Two carriers wrap those bytes: the json_body=False string,
        # and the small-binary {"_base64","data","size"} stub from the parse path.
        if isinstance(body, dict) and body.get("_base64"):
            return _document_from_base64(body["data"], name, ctx)
        if not self._config.json_body:
            return _document_from_base64(body, name, ctx)
        return _asset_from_value(Document, body, name, ctx)

    def _write_sync(self, request_id, log_entry, model_cid, model_name,
                    adapter_cid=None, adapter_name=None, marks=None):
        marks = {} if marks is None else marks
        req_ctx = None
        try:
            req_ctx = Context.new(f"req-{request_id}")
            base = self._base_manifest()

            request_dict = copy.deepcopy(log_entry["request"])
            if not self._config.include_request_header:
                request_dict.pop("headers", None)

            eq_request_body = self._isolate_body(request_dict, "Request Body", req_ctx)
            eq_request_dict = _document_from_collection(request_dict, "Request", req_ctx)

            code = log_entry["route_source"]
            eq_code = _asset_from_value(Code, code, "Code", req_ctx)

            # Optional guardrail-policy evidence (set by GuardrailAttestor):
            # attests which rule set produced the verdict.
            eq_policy = None
            policy_dir = log_entry.get("policy_dir")
            if policy_dir and os.path.isdir(policy_dir):
                eq_policy = Document.with_context(req_ctx).from_path(
                    policy_dir, name=log_entry.get("policy_name", "Guardrail Policy")
                )

            response_dict = copy.deepcopy(log_entry["response"])
            if not self._config.include_response_header:
                response_dict.pop("headers", None)

            eq_response_body = self._isolate_body(response_dict, "Response Body", req_ctx)
            eq_response_dict = _asset_from_value(Document, response_dict, "Response", req_ctx)

            function_name = log_entry["route_info"]["function_name"]
            comp = Computation.with_context(req_ctx).new(
                name=f"{function_name}",
                description=f"{function_name}",
            )
            comp.add_input_cid(eq_request_dict.cid)
            comp.add_input_cid(eq_code.cid)
            if eq_request_body is not None:
                comp.add_input_cid(eq_request_body.cid)
            if eq_policy is not None:
                comp.add_input_cid(eq_policy.cid)

            if model_cid is not None:
                # model_cid crosses the thread boundary as a plain string;
                # eqty_sdk 2.1.2 add_input_cid accepts only CID objects.
                if isinstance(model_cid, str):
                    from eqty_sdk import CID
                    model_cid = CID(model_cid)
                # Re-declare the Model in req_ctx by CID (no rehashing) so the
                # manifest contains a proper Model node, not a bare input edge.
                Model.with_context(req_ctx).from_cid(model_cid, name=model_name)
                comp.add_input_cid(model_cid)
            else:
                logger.warning(f"No model associated with request {request_id}")

            if adapter_cid is not None:
                # Same by-CID re-declaration as the base model: a proper Model
                # node for the adapter composition, no rehash on the request
                # path. Present only when the request named the adapter.
                if isinstance(adapter_cid, str):
                    from eqty_sdk import CID
                    adapter_cid = CID(adapter_cid)
                Model.with_context(req_ctx).from_cid(adapter_cid, name=adapter_name)
                comp.add_input_cid(adapter_cid)

            comp.add_output_cid(eq_response_dict.cid)
            if eq_response_body is not None:
                comp.add_output_cid(eq_response_body.cid)

            comp.finalize()
            marks["statements"] = time.time()

            manifest_file = self.log_directory / f"{request_id}.manifest.json"
            # not *.manifest.json, so neither the GET route nor _prune sees a partial file
            partial = self.log_directory / f".{request_id}.partial"
            try:
                req_ctx.export(partial)
                marks["export"] = time.time()
                if base is not None:
                    merged = _merge_manifests(base, json.loads(partial.read_bytes()))
                    partial.write_bytes(
                        json.dumps(merged, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
                    )
                marks["merge"] = time.time()
                os.replace(partial, manifest_file)
                marks["ready"] = time.time()
                marks["bytes"] = manifest_file.stat().st_size
            finally:
                partial.unlink(missing_ok=True)
        finally:
            if req_ctx is not None:
                try:
                    req_ctx.delete_tree()
                except Exception as e:
                    logger.warning(f"Failed to delete request context for {request_id}: {e}")
            marks["cleanup"] = time.time()
