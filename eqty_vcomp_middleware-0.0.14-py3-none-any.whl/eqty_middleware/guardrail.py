"""Signed integrity manifests for guardrail decisions.

``GuardrailAttestor`` writes one signed manifest per guarded turn, so a refusal
is as verifiable as a completion: ``attest_input_block`` for a request an
input rail blocked pre-inference (no model request; the refusal is the rail's
output), ``attest_streamed_exchange`` for a full turn (input/output rail
verdicts joined to the imported inference lineage, policy + judge CIDs, and
both notary DID registrations).

The signer is selected from ``EQTY_NOTARY``: ``vcomp-coco`` -> in-guest CoCo
notary, ``vcomp-crt`` -> CRT notary, unset -> a random local SECP256R1 key.
"""
import base64
import json
import logging
import os
import tempfile
import time
import urllib.request
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional, Union

from eqty_sdk import (
    Context,
    DID,
    Signer,
    SIGNER_ALGORITHMS,
    init,
    set_active_signer,
)

from .config import Config
from ._notary import make_notary_rebind_hook, wait_for_notary_key_settle

logger = logging.getLogger(__name__)

DEFAULT_VCOMP_CRT_NOTARY_URL = "http://docker.eqtylab.internal:8066"
DEFAULT_VCOMP_COCO_NOTARY_URL = "http://127.0.0.1:8066"

# One shared metadata name for the policy asset so block and exchange manifests
# register the identical node for the same policy-dir CID.
POLICY_ASSET_NAME = "Guardrail Policy (NeMo config.yml + prompts.yml)"


def _b64(b: Union[bytes, str]) -> str:
    if isinstance(b, str):
        b = b.encode("utf-8")
    return base64.b64encode(b).decode("ascii")


class GuardrailAttestor:
    """Writes signed manifests for guardrail decisions.

    Self-contained: bootstraps its own eqty-sdk signer (from ``EQTY_NOTARY``)
    and its own ``_ManifestWriter`` thread, so it runs standalone in a process
    that does not wrap a model server. Pointed at the same notary as a
    co-located ``IntegrityFastAPI`` server, its manifests share that server's
    signing key and ``log_directory`` namespace.
    """

    def __init__(
        self,
        log_directory: str,
        notary_url: Optional[str] = None,
        config: Optional[Config] = None,
        policy_dir: Optional[str] = None,
    ):
        from .manifest_writer import _ManifestWriter  # avoid importing the writer before eqty_sdk is set up

        self._config = config or Config.from_env()
        # Effective policy dir (exact config.yml/prompts.yml the rails engine
        # loaded); content-addressed into every manifest as evidence of which
        # rules were enforced.
        self._policy_dir = policy_dir if policy_dir and os.path.isdir(policy_dir) else None
        if policy_dir and self._policy_dir is None:
            logger.warning(f"policy_dir {policy_dir!r} not a directory; policy not attested")
        # (cid, name) of the judge model, discovered from the first imported
        # inference manifest and cached for input-blocked turns.
        self._judge: Optional[tuple] = None
        logging.getLogger("eqty_middleware").setLevel(
            logging.DEBUG if self._config.debug else logging.INFO
        )
        self.log_directory = Path(log_directory)
        self.log_directory.mkdir(parents=True, exist_ok=True)
        self._model_manifest_path = self.log_directory / "base_model.manifest.json"
        self._base_ctx = Context.new("eqty-guardrail")
        self._bootstrap_signer(notary_url)
        self._writer = _ManifestWriter(
            self.log_directory, self._model_manifest_path, self._config
        )
        self._writer.pre_write_hook = self._rebind_hook

    def _bootstrap_signer(self, notary_url: Optional[str]):
        """Init the SDK + active signer exactly like IntegrityFastAPI, keyed on
        EQTY_NOTARY, so block manifests are signed identically to inference
        manifests."""
        eqty_notary = os.getenv("EQTY_NOTARY", None)
        if eqty_notary == "vcomp":  # legacy alias
            eqty_notary = "vcomp-crt"
        default_url = (
            DEFAULT_VCOMP_COCO_NOTARY_URL
            if eqty_notary == "vcomp-coco"
            else DEFAULT_VCOMP_CRT_NOTARY_URL
        )
        notary_url = notary_url or os.getenv("EQTY_NOTARY_URL") or default_url
        os.makedirs(self._config.sdk_home, exist_ok=True)

        (
            init(default_context=self._base_ctx, custom_dir=self._config.sdk_home)
            .set_store_all_blobs(True)
            .set_cid_ignore_rules(include_symlinks=True)
        )

        if eqty_notary in ("vcomp-crt", "vcomp-coco"):
            logger.info(
                f"GuardrailAttestor: VCOMP notary ({eqty_notary}) at {notary_url}"
            )
            wait_for_notary_key_settle(notary_url)  # see _notary.py
            signer = Signer.vcomp_notary(
                notary_url, name="VCOMP Container Notary", _load_if_exists=True
            )
        else:
            logger.warning(
                "GuardrailAttestor: no EQTY_NOTARY set - using a random local "
                "SECP256R1 signer (not TEE-bound)"
            )
            signer = Signer.new(
                SIGNER_ALGORITHMS.SECP256R1, name="Signing Key", _load_if_exists=True
            )
        set_active_signer(signer)
        DID.from_signer(
            signer,
            name="Guardrail Signer",
            description="Signing key for guardrail-block integrity manifests.",
        )
        # Re-bind if the notary key rotates after this bind; the writer runs
        # this hook before each export.
        self._rebind_hook = (
            make_notary_rebind_hook(
                notary_url,
                signer_name="VCOMP Container Notary",
                did_name="Guardrail Signer",
                did_description="Signing key for guardrail-block integrity manifests.",
            )
            if eqty_notary in ("vcomp-crt", "vcomp-coco")
            else None
        )

    def _body_repr(self, body: Union[bytes, str]):
        """Represent a body the same way IntegrityFastAPI._process_body does,
        so its CID is computed over the exact wire bytes."""
        if isinstance(body, str):
            body = body.encode("utf-8")
        if not self._config.json_body:
            return base64.b64encode(body).decode("ascii")
        try:
            decoded = body.decode("utf-8")
            try:
                return json.loads(decoded)
            except json.JSONDecodeError:
                return decoded
        except UnicodeDecodeError:
            return base64.b64encode(body).decode("ascii")

    def attest_input_block(
        self,
        *,
        request_id: str,
        request_body: Union[bytes, str],
        input_verdict: dict,
        response_body: Union[bytes, str],
        did_import_paths: Optional[list] = None,
        model_name: str = "Model",
    ) -> str:
        """One self-contained manifest for a turn the input rails blocked (or
        failed closed on). No generation request was sent, so there is no
        model/inference node: a single ``input_guardrail`` computation maps
        the client request + policy + judge to the verdict AND the refusal
        ``response_body`` - the exact bytes returned to the client.
        """
        self._writer.submit(
            lambda: self._build_input_block_sync(
                request_id, request_body, input_verdict, response_body,
                did_import_paths or [], model_name,
            )
        )
        logger.info(
            f"input block manifest queued: {request_id} "
            f"(rail={input_verdict.get('rail')!r})"
        )
        return request_id

    def _build_input_block_sync(self, request_id, request_body, input_verdict,
                                response_body, did_import_paths, model_name):
        from .manifest_writer import _asset_from_value, _document_from_base64
        from eqty_sdk import Computation, Document

        ctx = Context.new(f"exchange-{request_id}")
        try:
            client_req_cid = _document_from_base64(
                _b64(request_body), "Client Request", ctx).cid
            eq_iv = _asset_from_value(Document, json.dumps(input_verdict, sort_keys=True),
                                      "Input Guardrail Verdict", ctx)
            eq_delivered = _asset_from_value(
                Document, response_body, "Delivered Response", ctx)
            policy_cid, judge_name_cid = self._policy_and_judge_nodes(ctx, model_name)

            c = Computation.with_context(ctx).new(
                name="input_guardrail",
                description="NeMo input rails screen the client request and BLOCK it "
                            "before generation: no request is sent to the model. "
                            "Outputs: the guardrail verdict and the Delivered Response "
                            "(the refusal the client actually received).",
            )
            for cid in (client_req_cid, policy_cid, judge_name_cid):
                if cid:
                    c.add_input_cid(cid)
            c.add_output_cid(eq_iv.cid)
            c.add_output_cid(eq_delivered.cid)
            c.finalize()

            out_path = self.log_directory / f"{request_id}.manifest.json"
            ctx.export(out_path)
            merged_dids = self._merge_did_docs(out_path, did_import_paths)
            logger.info(
                f"input block manifest {request_id} (dids_merged={merged_dids})"
            )
        finally:
            try:
                ctx.delete_tree()
            except Exception as e:
                logger.warning(f"input block ctx cleanup failed for {request_id}: {e}")

    def _policy_and_judge_nodes(self, ctx, model_name: str) -> tuple:
        """(policy_cid, judge_name_cid) shared by every guardrail computation.
        The judge is recorded by NAME only - what the guardrail independently
        knows from its policy config; the model CID is the server's attestation."""
        from .manifest_writer import _asset_from_value
        from eqty_sdk import Document

        policy_cid = None
        if self._policy_dir:
            policy_cid = Document.with_context(ctx).from_path(
                self._policy_dir, name=POLICY_ASSET_NAME
            ).cid
        judge_name = self._judge[1] if self._judge else model_name
        judge_name_cid = _asset_from_value(
            Document, judge_name, "Judge Model Name", ctx
        ).cid
        return policy_cid, judge_name_cid

    def attest_exchange(
        self,
        *,
        request_body: Union[bytes, str],
        input_verdict: dict,
        response_body: Union[bytes, str],
        output_verdict: dict,
        model_name: str = "Model",
        request_id: Optional[str] = None,
        inference_manifest_url: Optional[str] = None,
    ) -> str:
        """Write ONE reconciled manifest for a full guardrailed exchange: an
        input_guardrail computation, the imported inference lineage (fetched
        from ``inference_manifest_url``, with retry - written async), and an
        output_guardrail computation. ``request_body``/``response_body`` must
        be the exact bytes the model server hashed, so CIDs reconcile by
        content. Degrades to guardrail-only (no imported lineage) if the
        inference manifest isn't available. Returns the exchange manifest id.
        """
        request_id = request_id or str(uuid.uuid4())
        self._writer.submit(
            lambda: self._build_exchange_sync(
                request_id, request_body, input_verdict, response_body,
                output_verdict, model_name, inference_manifest_url,
            )
        )
        return request_id

    def _build_exchange_sync(self, request_id, request_body, input_verdict,
                             response_body, output_verdict, model_name,
                             inference_manifest_url):
        from eqty_sdk import Computation, Document, Model
        from .manifest_writer import _asset_from_value, _document_from_base64

        ctx = Context.new(f"exchange-{request_id}")
        imported = False
        try:
            # The server writes its manifest asynchronously; retry briefly.
            if inference_manifest_url:
                for _ in range(15):
                    try:
                        with urllib.request.urlopen(inference_manifest_url, timeout=5) as r:
                            if r.status != 200:
                                raise IOError(f"status {r.status}")
                            data = r.read()
                        fd, p = tempfile.mkstemp(suffix=".manifest.json")
                        try:
                            with os.fdopen(fd, "wb") as f:
                                f.write(data)
                            ctx.import_manifest(p)
                            imported = True
                        finally:
                            os.remove(p)
                        break
                    except Exception:
                        time.sleep(1)
                if not imported:
                    logger.warning(
                        f"exchange {request_id}: inference manifest not available "
                        f"at {inference_manifest_url}; writing guardrail-only exchange"
                    )

            # base64 of the raw wire bytes, matching the server's representation,
            # so CIDs align onto shared nodes.
            eq_req = _document_from_base64(_b64(request_body), "User Request", ctx)
            eq_iv = _asset_from_value(Document, json.dumps(input_verdict, sort_keys=True),
                                      "Input Guardrail Verdict", ctx)
            eq_resp = _document_from_base64(_b64(response_body), "Model Response", ctx)
            eq_ov = _asset_from_value(Document, json.dumps(output_verdict, sort_keys=True),
                                      "Output Guardrail Verdict", ctx)

            # The effective policy is an input to both rail computations, so a
            # policy change is traceable through the CID.
            eq_policy = None
            if self._policy_dir:
                eq_policy = Document.with_context(ctx).from_path(
                    self._policy_dir, name=POLICY_ASSET_NAME
                )

            c_in = Computation.with_context(ctx).new(
                name="input_guardrail",
                description="NeMo input rails: screen the user request before inference.",
            )
            c_in.add_input_cid(eq_req.cid)
            if eq_policy is not None:
                c_in.add_input_cid(eq_policy.cid)
            c_in.add_output_cid(eq_iv.cid)
            c_in.finalize()

            c_out = Computation.with_context(ctx).new(
                name="output_guardrail",
                description="NeMo output rails: screen the model response before return.",
            )
            c_out.add_input_cid(eq_resp.cid)
            if eq_policy is not None:
                c_out.add_input_cid(eq_policy.cid)
            c_out.add_output_cid(eq_ov.cid)
            c_out.finalize()

            ctx.export(self.log_directory / f"{request_id}.manifest.json")
            logger.info(
                f"reconciled exchange manifest {request_id} "
                f"(inference_imported={imported})"
            )
        finally:
            try:
                ctx.delete_tree()
            except Exception as e:
                logger.warning(f"exchange ctx cleanup failed for {request_id}: {e}")

    @staticmethod
    def _find_named_in_manifest(manifest: dict, name: str) -> Optional[str]:
        """Subject CID of the asset registered under metadata ``name`` in a
        fetched manifest (e.g. the inference step's "Request Body")."""
        for s in (manifest.get("statements") or {}).values():
            if not (isinstance(s, dict) and s.get("@type") == "MetadataRegistration"):
                continue
            try:
                blob = manifest["blobs"][s["metadata"].replace("urn:cid:", "")]
                if json.loads(base64.b64decode(blob)).get("name") == name:
                    return s["subject"]
            except Exception:
                continue
        return None

    @staticmethod
    def _find_model_in_manifest(manifest: dict) -> Optional[tuple]:
        """(cid, name) of the Model asset registered in a fetched inference
        manifest - the model that generated AND judged (self-check) the turn."""
        for s in (manifest.get("statements") or {}).values():
            if not (isinstance(s, dict) and s.get("@type") == "MetadataRegistration"):
                continue
            try:
                blob = manifest["blobs"][s["metadata"].replace("urn:cid:", "")]
                md = json.loads(base64.b64decode(blob))
            except Exception:
                continue
            if md.get("assetType") == "Model":
                return s["subject"], md.get("name") or "Model"
        return None

    def attest_streamed_exchange(
        self,
        *,
        request_id: str,
        request_body: Union[bytes, str],
        input_verdict: dict,
        response_text: str,
        output_verdict: dict,
        inference_manifest_url: Optional[str] = None,
        did_import_paths: Optional[list] = None,
        model_name: str = "Model",
    ) -> str:
        """One self-contained manifest for a NeMo-driven streamed turn.
        ``response_text`` is the text actually delivered to the client (a
        partial prefix on a mid-stream block). The policy and judge model are
        inputs to both guardrail computations; ``did_import_paths`` (training +
        serving notary DID registrations) are folded in so the manifest
        verifies stand-alone.
        """
        self._writer.submit(
            lambda: self._build_streamed_exchange_sync(
                request_id, request_body, input_verdict, response_text,
                output_verdict, inference_manifest_url, did_import_paths or [],
                model_name,
            )
        )
        return request_id

    @staticmethod
    def _merge_did_docs(manifest_path, did_paths) -> int:
        """Fold DID-registration manifests (training + serving notary TEE
        evidence) into an exported exchange manifest at the JSON level. Keys
        are content CIDs, so colliding entries are identical and the merge
        cannot corrupt existing statements. Returns docs merged."""
        if not did_paths:
            return 0
        merged = 0
        try:
            with open(manifest_path) as f:
                manifest = json.load(f)
            for p in did_paths:
                try:
                    with open(p) as f:
                        doc = json.load(f)
                    if not doc.get("statements"):
                        raise ValueError("no statements")
                    for key in ("contexts", "statements", "blobs"):
                        target = manifest.setdefault(key, {})
                        for k, v in (doc.get(key) or {}).items():
                            target.setdefault(k, v)
                    merged += 1
                except Exception as e:
                    logger.warning(f"DID doc merge failed for {p}: {e}")
            if merged:
                with open(manifest_path, "w") as f:
                    json.dump(manifest, f)
        except Exception as e:
            logger.warning(f"DID merge into {manifest_path} failed: {e}")
        return merged

    def _fetch_manifest_with_retry(self, url: str, attempts: int = 15) -> Optional[dict]:
        for _ in range(attempts):
            try:
                with urllib.request.urlopen(url, timeout=5) as r:
                    if r.status != 200:
                        raise IOError(f"status {r.status}")
                    data = json.loads(r.read())
                if data.get("statements"):
                    return data
            except Exception:
                pass
            time.sleep(1)
        return None

    def _build_streamed_exchange_sync(self, request_id, request_body, input_verdict,
                                      response_text, output_verdict,
                                      inference_manifest_url, did_import_paths,
                                      model_name="Model"):
        from eqty_sdk import CID, Computation, Document, Model
        from .manifest_writer import _asset_from_value, _document_from_base64

        def import_json(ctx, payload: dict, label: str) -> bool:
            fd, p = tempfile.mkstemp(suffix=".manifest.json")
            try:
                with os.fdopen(fd, "w") as f:
                    json.dump(payload, f)
                ctx.import_manifest(p)
                return True
            except Exception as e:
                logger.warning(f"exchange {request_id}: import of {label} failed: {e}")
                return False
            finally:
                os.remove(p)

        ctx = Context.new(f"exchange-{request_id}")
        try:
            imported = False
            manifest = None
            if inference_manifest_url:
                manifest = self._fetch_manifest_with_retry(inference_manifest_url)
                if manifest:
                    found = self._find_model_in_manifest(manifest)
                    if found:
                        # cache so input-blocked turns (no inference) still
                        # carry the judge on their input_guardrail computation
                        self._judge = found
                    imported = import_json(ctx, manifest, "inference manifest")
                if not imported:
                    logger.warning(
                        f"exchange {request_id}: inference manifest unavailable at "
                        f"{inference_manifest_url}; writing guardrail-only exchange"
                    )

            # DID docs are merged into the exported JSON (below) rather than
            # ctx.import_manifest'ed: on eqty_sdk 2.1.2 a Did/Credential-only
            # manifest imports into the index but its statements never attach
            # to the context.

            # Client request: always its own node (exact bytes the user sent).
            client_req_cid = _document_from_base64(_b64(request_body), "Client Request", ctx).cid

            # Model request: the body _model_stream rebuilt and sent to the model
            # (stream forced True, temperature defaulted). Sourced from the imported
            # inference manifest's "Request Body" so the two manifests share one node.
            # When no inference manifest is available both are treated as the same node.
            model_req_cid = resp_cid = None
            if manifest is not None:
                rb = self._find_named_in_manifest(manifest, "Request Body")
                sb = self._find_named_in_manifest(manifest, "Response Body")
                model_req_cid = CID(rb) if rb else None
                resp_cid = CID(sb) if sb else None
            if model_req_cid is None:
                model_req_cid = client_req_cid
            # resp_cid stays None when no inference manifest is available; the
            # output_guardrail computation will still record Delivered Response.

            eq_iv = _asset_from_value(Document, json.dumps(input_verdict, sort_keys=True),
                                      "Input Guardrail Verdict", ctx)
            eq_ov = _asset_from_value(Document, json.dumps(output_verdict, sort_keys=True),
                                      "Output Guardrail Verdict", ctx)

            # Re-declare the Model node from the imported manifest so the two
            # manifests share that node by CID. The guardrail computations below
            # reference only the model name (what the guardrail independently
            # knows from its policy config), not the model CID (which belongs
            # to the model server's attestation).
            if self._judge:
                judge_str, judge_name = self._judge
                Model.with_context(ctx).from_cid(CID(judge_str), name=judge_name)

            def rail_comp(name, description, io_in, outs):
                c = Computation.with_context(ctx).new(name=name, description=description)
                for cid in io_in:
                    if cid:
                        c.add_input_cid(cid)
                for cid in (outs if isinstance(outs, list) else [outs]):
                    if cid:
                        c.add_output_cid(cid)
                c.finalize()

            policy_cid, judge_name_cid = self._policy_and_judge_nodes(ctx, model_name)

            # Delivered Response: exactly what the guardrail forwarded to the
            # client — the full response on a pass, a truncated prefix on a
            # mid-stream block. Always a distinct node so the manifest proves
            # what the browser received regardless of what the model generated.
            eq_delivered = _asset_from_value(
                Document, response_text, "Delivered Response", ctx
            )

            # rails_transform: bridges the client request to the model request,
            # showing 1:1 that the rails repackaged the body before inference.
            # Only emitted when the two are distinct nodes (inference manifest present).
            if model_req_cid is not client_req_cid:
                rt = Computation.with_context(ctx).new(
                    name="rails_transform",
                    description="NeMo rails repackage the client request into the model "
                                "request (stream forced True, temperature defaulted) "
                                "before forwarding to the model.",
                )
                rt.add_input_cid(client_req_cid)
                if policy_cid is not None:
                    rt.add_input_cid(policy_cid)
                rt.add_output_cid(model_req_cid)
                rt.finalize()

            rail_comp(
                "input_guardrail",
                "NeMo input rails screen the client request before generation.",
                [client_req_cid, policy_cid, judge_name_cid], eq_iv.cid,
            )
            rail_comp(
                "output_guardrail",
                "NeMo streaming output rails screen the model's Response Body and "
                "forward the result to the client. Outputs: the guardrail verdict and "
                "the Delivered Response (the token stream the client actually received; "
                "equal to Response Body on a pass, a truncated prefix on a mid-stream "
                "block — delivered_chunks/delivered_bytes in the verdict record the cut).",
                [resp_cid, policy_cid, judge_name_cid],
                [eq_ov.cid, eq_delivered.cid],
            )

            out_path = self.log_directory / f"{request_id}.manifest.json"
            ctx.export(out_path)
            merged_dids = self._merge_did_docs(out_path, did_import_paths)
            logger.info(
                f"streamed exchange manifest {request_id} (inference_imported="
                f"{imported}, dids_merged={merged_dids}, judge={bool(self._judge)})"
            )
        finally:
            try:
                ctx.delete_tree()
            except Exception as e:
                logger.warning(f"exchange ctx cleanup failed for {request_id}: {e}")

    def drain(self, timeout: Optional[float] = None):
        """Flush pending manifest writes (block + exchange) on graceful shutdown."""
        self._writer.drain(
            timeout if timeout is not None else self._config.drain_timeout
        )
