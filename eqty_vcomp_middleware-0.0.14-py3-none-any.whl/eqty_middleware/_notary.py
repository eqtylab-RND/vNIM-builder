"""Notary key-settle helper.

The in-guest CoCo notary mints a fresh container signing key on every kata
``config.json`` rewrite, including one a few seconds after container start. A
DID bound before that rotation goes stale: the notary later signs with the
rotated key, so its ``verificationMethod`` no longer matches and VC proofs fail.

Poll ``/v1/public_key`` until it stops changing before binding the DID.
"""
import hashlib
import json
import logging
import time
import urllib.request

logger = logging.getLogger(__name__)


def notary_public_key(notary_url: str):
    """Current notary signing key (``/v1/public_key``), or None if unreachable."""
    url = notary_url.rstrip("/") + "/v1/public_key"
    try:
        with urllib.request.urlopen(url, timeout=5) as r:
            return (json.loads(r.read().decode()) or {}).get("public_key")
    except Exception:
        return None


def make_notary_rebind_hook(
    notary_url: str,
    *,
    signer_name: str,
    did_name: str,
    did_description: str,
):
    """Return a zero-arg hook that re-binds the active DID when the notary's key
    has rotated since the last bind (e.g. a second, later-starting notary client
    in the same pod rotates the key after this process already settled). Cheap
    when nothing changed; call it on the manifest-writer thread before each
    signed export.
    """
    from eqty_sdk import DID, Signer, set_active_signer

    state = {"key": notary_public_key(notary_url)}

    def hook():
        cur = notary_public_key(notary_url)
        if not cur or cur == state["key"]:
            return
        logger.warning(
            "notary key rotated since bind; re-registering DID so new "
            "credentials match the current signing key"
        )
        # A vcomp signer's did_key is fixed at creation (fetched from
        # /v1/public_key), and eqty-sdk>=2.3 refuses to re-create a signer
        # under an existing name - so name it per key. If the notary rotates
        # back to a key seen before, _load_if_exists loads the signer that is
        # already bound to exactly that key.
        key_tag = hashlib.sha256(cur.encode("utf-8")).hexdigest()[:12]
        signer = Signer.vcomp_notary(
            notary_url, name=f"{signer_name} {key_tag}", _load_if_exists=True
        )
        set_active_signer(signer)
        DID.from_signer(signer, name=did_name, description=did_description)
        state["key"] = cur

    return hook


def wait_for_notary_key_settle(
    notary_url: str,
    *,
    need_stable: int = 5,
    poll_secs: float = 3.0,
    max_polls: int = 80,
) -> None:
    """Block until the notary's public key is unchanged for ``need_stable``
    consecutive polls. Non-fatal: on timeout it logs a warning and returns so
    startup proceeds with whatever key is current."""
    prev = None
    stable = 0
    for i in range(max_polls):
        cur = notary_public_key(notary_url)
        if cur and cur == prev:
            stable += 1
            if stable >= need_stable:
                logger.info("notary container key settled after ~%.0fs", i * poll_secs)
                return
        else:
            stable = 0
        prev = cur
        time.sleep(poll_secs)
    logger.warning(
        "notary key did not settle within ~%.0fs; proceeding with current key",
        max_polls * poll_secs,
    )
