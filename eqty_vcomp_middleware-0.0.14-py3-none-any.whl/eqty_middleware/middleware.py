import asyncio
import base64
import inspect
import json
import logging
import os
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Dict, Optional

from fastapi import APIRouter, FastAPI, Request, Response
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import JSONResponse, StreamingResponse

from .config import Config
from ._notary import make_notary_rebind_hook, wait_for_notary_key_settle
from .manifest_writer import _ManifestWriter
from .model_source import (
    _served_model_name,
    get_hf_path_from_name,
    locate_nim_snapshot_dir,
)

from eqty_sdk import (
    Context,
    DID,
    Model,
    Signer,
    SIGNER_ALGORITHMS,
    init,
    set_active_signer,
)

logger = logging.getLogger(__name__)

DEFAULT_VCOMP_CRT_NOTARY_URL = "http://docker.eqtylab.internal:8066"
DEFAULT_VCOMP_COCO_NOTARY_URL = "http://127.0.0.1:8066"

# Bootstrap state is stashed on the wrapped FastAPI app under this attribute so
# it is scoped per-application and survives Starlette's stack rebuild, instead
# of leaking across unrelated apps through a module global.
_BOOTSTRAP_ATTR = "_eqty_integrity_bootstrap"


# Endpoints explicitly opted out of attestation. Keyed on the *function object*,
# not its __name__: two unrelated routes can share a name (e.g. both called
# ``get``), so a name-keyed set would silently exclude the wrong one.
EXCLUDED_PATHS: set = set()


def eqty_exclude_from_integrity():
    def decorator(func):
        EXCLUDED_PATHS.add(func)
        return func
    return decorator


# This middleware is workload-agnostic: it hardcodes ONLY the paths it owns and
# never guesses the wrapped server's surface. The owned paths - the integrity
# read routes it injects and the notary's did-registration - are ALWAYS excluded
# (even under attest_all), because attesting them is self-referential and
# meaningless. Every server-specific infra/probe/metadata path (/v1/models,
# /health, /metrics, NIM's /v1/health/ready, a custom app's /status, ...) is
# declared by the operator via EQTY_MIDDLEWARE_EXCLUDE_PATHS (exact, or a
# trailing-'*' prefix); /tmp/api_logs growth is bounded regardless by log
# retention (Config.log_max_files). EQTY_MIDDLEWARE_ATTEST_ALL=true measures
# everything except the owned paths.
_EQTY_OWN_PREFIXES = ("/integrity", "/.well-known")


def _path_matches(path: str, pattern: str) -> bool:
    """Exact match, or a prefix match when the pattern ends in '*'."""
    if pattern.endswith("*"):
        return path.startswith(pattern[:-1])
    return path == pattern


def _path_excluded_from_integrity(path: Optional[str], config: Optional[Config] = None) -> bool:
    # config defaults to a fresh env read so the check is callable standalone and
    # never reads env at import time.
    if not path:
        return False
    if config is None:
        config = Config.from_env()
    # The middleware's own surface is isolated and unconditionally excluded.
    if any(path.startswith(pre) for pre in _EQTY_OWN_PREFIXES):
        return True
    if config.attest_all:
        return False
    return any(_path_matches(path, pat) for pat in config.exclude_paths)


class IntegrityFastAPI(BaseHTTPMiddleware):
    def __init__(self, app: FastAPI, fastapi_app, log_directory: str = "request_logs",
                 model_cid: str = None,
                 delay_start: bool = False,
                 notary_url: Optional[str] = None,
                 config: Optional[Config] = None):
        super().__init__(app)
        self._fastapi_app = fastapi_app
        self.model_cid = model_cid
        self._config = config or Config.from_env()
        logging.getLogger("eqty_middleware").setLevel(
            logging.DEBUG if self._config.debug else logging.INFO
        )
        # inspect.getsource is slow and blocking; cache it per endpoint.
        self._source_cache: Dict[Any, str] = {}

        # reuse the per-app bootstrap if this app's middleware stack is
        # rebuilt (Starlette restack / NIM startup) rather than re-running the
        # SDK init + model registration and re-registering a duplicate signer.
        bootstrap = getattr(fastapi_app, _BOOTSTRAP_ATTR, None)
        if bootstrap is not None:
            self.log_directory = bootstrap["log_directory"]
            self._model_manifest_path = bootstrap["_model_manifest_path"]
            self._base_ctx = bootstrap["_base_ctx"]
            self.eqty = bootstrap["eqty"]
            self._model_hashes = bootstrap["_model_hashes"]
            self._fixed_model = bootstrap["_fixed_model"]
            self._last_registered_model_name = bootstrap["_last_registered_model_name"]
            self._writer = bootstrap["_writer"]
            self._config = bootstrap["config"]
            set_active_signer(bootstrap["signer"])
            logger.info("IntegrityFastAPI: reusing existing context (already bootstrapped)")
            return

        self.log_directory = Path(log_directory)
        self.log_directory.mkdir(parents=True, exist_ok=True)
        self._model_hashes: Dict[str, Model] = {}
        self._fixed_model: Optional[str] = None
        # Name of the most recently registered model; the dispatch fallback label
        # when no per-request model can be resolved (was _KLUDGE_model_name).
        self._last_registered_model_name = ""

        self._model_manifest_path = self.log_directory / "base_model.manifest.json"
        self._writer = _ManifestWriter(
            self.log_directory, self._model_manifest_path, self._config,
        )

        eqty_notary = os.getenv('EQTY_NOTARY', None)
        # "vcomp" is the legacy alias for "vcomp-crt"; keep it working.
        if eqty_notary == "vcomp":
            eqty_notary = "vcomp-crt"

        if eqty_notary == "vcomp-coco":
            default_notary_url = DEFAULT_VCOMP_COCO_NOTARY_URL
        else:
            default_notary_url = DEFAULT_VCOMP_CRT_NOTARY_URL
        notary_url = notary_url or os.getenv('EQTY_NOTARY_URL') or default_notary_url

        os.makedirs(self._config.sdk_home, exist_ok=True)

        logger.info("Starting TEE Notary Init")

        # 2.x: every asset/computation is scoped to a Context. Establish a
        # base context that holds the model + its signing statements; each
        # request will create its own child-style context for isolation.
        self._base_ctx = Context.new("eqty-middleware")

        if eqty_notary in ("vcomp-crt", "vcomp-coco"):
            logger.info(f"Initializing TEE Notary Key ({eqty_notary}) against {notary_url}")
            self.eqty = (
                init(default_context=self._base_ctx, custom_dir=self._config.sdk_home)
                .set_store_all_blobs(True)
                .set_cid_ignore_rules(include_symlinks=True)
            )
            wait_for_notary_key_settle(notary_url)  # see _notary.py
            signer = Signer.vcomp_notary(
                notary_url,
                name="VCOMP Container Notary",
                _load_if_exists=True,
            )
            set_active_signer(signer)
            DID.from_signer(
                signer,
                name="VCOMP Container Notary",
                description="VCOMP signing key for integrity statements.",
            )
            # A co-located second notary client can rotate the key after this
            # bind; re-bind on the writer thread if it changes.
            self._writer.pre_write_hook = make_notary_rebind_hook(
                notary_url,
                signer_name="VCOMP Container Notary",
                did_name="VCOMP Container Notary",
                did_description="VCOMP signing key for integrity statements.",
            )
        else:
            logger.warning("Initializing Random Notary Key")
            logger.warning("Remember to backup your private key if you need to reference it again")
            self.eqty = (
                init(default_context=self._base_ctx, custom_dir=self._config.sdk_home)
                .set_store_all_blobs(True)
                .set_cid_ignore_rules(include_symlinks=True)
            )
            signer = Signer.new(
                SIGNER_ALGORITHMS.SECP256R1,
                name="Signing Key",
                _load_if_exists=True,
            )
            set_active_signer(signer)
            DID.from_signer(
                signer,
                name="Signing Key",
                description="Signing key for integrity statements.",
            )

        # Register /integrity/* unconditionally so the endpoints exist even when
        # delay_start defers model discovery.
        self._register_integrity_routes()

        if not delay_start:
            logger.info("Starting Model Initialization")
            self.initialize_model(None, None)
        else:
            logger.info("Delaying Model Initialization")

        setattr(fastapi_app, _BOOTSTRAP_ATTR, {
            "log_directory": self.log_directory,
            "_model_manifest_path": self._model_manifest_path,
            "_base_ctx": self._base_ctx,
            "eqty": self.eqty,
            "_model_hashes": self._model_hashes,
            "_fixed_model": self._fixed_model,
            "_last_registered_model_name": self._last_registered_model_name,
            "signer": signer,
            "_writer": self._writer,
            "config": self._config,
        })

    async def __call__(self, scope, receive, send):
        # Intercept the ASGI lifespan so a graceful shutdown drains pending
        # attestation writes before the process exits. HTTP traffic falls
        # straight through to BaseHTTPMiddleware.dispatch.
        if scope["type"] != "lifespan":
            return await super().__call__(scope, receive, send)

        async def send_wrapper(message):
            if message["type"] == "lifespan.shutdown.complete":
                try:
                    await asyncio.to_thread(self._writer.drain, self._config.drain_timeout)
                except Exception as e:
                    logger.error(f"attestation drain failed during shutdown: {e}")
            await send(message)

        await self.app(scope, receive, send_wrapper)

    def _model_kwargs(self):
        # 2.x: model signing is opt-in per asset. Only valid for SECP256R1 keys.
        return {"_enable_model_signing_signature": True} if self._config.enable_cosai else {}

    def _register_model(self, model_path: str, model_name: str, description: str):
        eq_model = Model.with_context(self._base_ctx).from_path(
            model_path,
            name=model_name,
            description=description,
            _store=False,
            **self._model_kwargs(),
        )
        self._last_registered_model_name = model_name
        self._model_hashes[model_name] = eq_model
        logger.info("Generating complete, exporting base model manifest")
        self._base_ctx.export(self._model_manifest_path)
        logger.info(f"Base model manifest exported to {self._model_manifest_path}")
        return eq_model

    def initialize_model(self, model_path: str = None, model_name: str = None):
        logger.info("Initializing model")
        fastapi_app = self._fastapi_app

        if model_name is not None and model_path is None:
            model_path = get_hf_path_from_name(model_name)

        if model_path and os.path.exists(model_path):
            logger.info(f"Model path provided: {model_path}")
            model_name = model_name or os.path.basename(model_path)
            self._register_model(model_path, model_name, f"Model at {model_path}")
            self._fixed_model = model_name
        elif model_path:
            logger.warning(f"Model path provided but does not exist: {model_path}")

        if self._fixed_model is None:
            if hasattr(fastapi_app, "state"):
                logger.info("Found State in app")

                if hasattr(fastapi_app.state, "openai_serving_models"):
                    logger.info("Found OpenAI server")
                    model_name = _served_model_name(fastapi_app)
                    model_path = get_hf_path_from_name(model_name) if model_name else None
                    if model_path is None:
                        # vLLM-direct NIMs (nemotron etc.) cache the model
                        # in the NIM NGC layout rather than the HF cache.
                        model_path = locate_nim_snapshot_dir(model_name) if model_name else None
                    if model_path is not None and model_name not in self._model_hashes:
                        self._register_model(model_path, model_name, model_name)
                    else:
                        logger.error("Open AI Check: Missing Model Path")
                else:
                    logger.info("Not OpenAI server, Checking NIM instead")
                    # os.environ.get returns None when unset (not ""), and many
                    # NIMs (e.g. qwen3.6 sglang) only set NIM_MODEL_NAME, never
                    # NIM_SERVED_MODEL_NAME. _served_model_name uses a falsy
                    # chain so we fall back whether the first var is missing or empty.
                    model_name = _served_model_name(fastapi_app)
                    if model_name:
                        snapshot_dir = locate_nim_snapshot_dir(model_name)
                        if snapshot_dir is None:
                            logger.warning(
                                "NIM CHECK: no snapshot dir found for "
                                f"{model_name}; skipping base model registration"
                            )
                        else:
                            logger.info(f"Found NIM model {model_name} at {snapshot_dir}")
                            self._register_model(snapshot_dir, model_name, model_name)
                    else:
                        logger.error("NIM CHECK: Missing model_name")
            else:
                logger.warning("FastAPI app has no .state; skipping model discovery")
                return
        # Only mark a fixed model if registration actually populated _model_hashes.
        # Otherwise dispatch would KeyError on a name with no hash (e.g. when
        # the NIM cache dir wasn't populated yet at init time).
        if model_name and model_name in self._model_hashes:
            self._fixed_model = model_name

    # Back-compat: apply-vllm-patch.py / vllm.patch call the misspelled
    # initalize_model() by walking the middleware stack. Keep the alias.
    initalize_model = initialize_model

    def _safe_log_path(self, request_id: str, suffix: str) -> Optional[Path]:
        """Resolve ``<log_dir>/<request_id><suffix>`` and refuse anything that
        escapes the log directory. ``request_id`` comes straight off the URL, so
        a value like ``../../etc/hostname`` must not read outside the dir."""
        base = self.log_directory.resolve()
        candidate = (base / f"{request_id}{suffix}").resolve()
        if not candidate.is_relative_to(base):
            return None
        return candidate

    def _register_integrity_routes(self):
        """Register /integrity/{logs,manifest} on the wrapped app. Called from
        __init__ unconditionally so the routes exist even when delay_start
        defers model discovery."""
        router = APIRouter(prefix="/integrity", tags=["integrity"])

        async def _serve_json(request_id: str, suffix: str):
            log_file = self._safe_log_path(request_id, suffix)
            # Uniform 404 for both "not found" and "path escapes dir" so the
            # endpoint never confirms files outside the log directory.
            if log_file is None or not log_file.exists():
                return JSONResponse(status_code=404, content={"detail": f"ID {request_id} not found"})
            try:
                content = await asyncio.to_thread(log_file.read_text)
                return json.loads(content)
            except Exception as e:
                return JSONResponse(status_code=500, content={"detail": f"Error reading file: {str(e)}"})

        @router.get("/logs/{request_id}", response_model=Dict[str, Any])
        @eqty_exclude_from_integrity()
        async def get_log_by_id(request_id: str):
            return await _serve_json(request_id, ".json")

        @router.get("/manifest/{request_id}", response_model=Dict[str, Any])
        @eqty_exclude_from_integrity()
        async def get_manifest_by_id(request_id: str):
            return await _serve_json(request_id, ".manifest.json")

        self._fastapi_app.include_router(router)

    def _endpoint_source(self, endpoint) -> str:
        """inspect.getsource for an endpoint, cached (slow + blocking)."""
        if endpoint is None:
            return "Unknown source"
        cached = self._source_cache.get(endpoint)
        if cached is None:
            try:
                cached = inspect.getsource(endpoint)
            except (OSError, TypeError) as e:
                logger.debug(f"getsource failed for {endpoint}: {e}")
                cached = "Unknown source"
            self._source_cache[endpoint] = cached
        return cached

    def _build_log_entry(self, request_id, request_data, response_data, source,
                         route_name, route_path, endpoint) -> dict:
        # One shape, built in one place, for both the streaming and buffered
        # branches.
        return {
            "request_id": request_id,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "request": request_data,
            "response": response_data,
            "route_source": source,
            "route_info": {
                "function_name": route_name,
                "path": route_path,
                "endpoint_module": endpoint.__module__ if endpoint else None,
            },
        }

    def _resolve_model(self, app):
        """(eq_model, model_cid, model_name) for the request's served model.

        Shares _served_model_name with init so dispatch can't drift from
        discovery. Only the CID *string* is later handed to the writer
        thread, never the live SDK object.
        """
        eq_model = None
        if self._fixed_model is not None and self._fixed_model in self._model_hashes:
            eq_model = self._model_hashes[self._fixed_model]
            logger.info(f"Found model being used: {self._fixed_model} (FIXED)")
        else:
            current = _served_model_name(app)
            if current and current in self._model_hashes:
                eq_model = self._model_hashes[current]
                logger.info(f"Found model being used: {current}")
            else:
                logger.debug("NO MODEL DEFINED!")
        model_cid = eq_model.cid if eq_model is not None else None
        model_name = self._fixed_model or self._last_registered_model_name or "Model"
        return eq_model, model_cid, model_name

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        logger.info("Starting dispatch")
        route = request.scope.get("route")
        route_path = getattr(route, "path", None) if route else None
        if route_path is None:
            route_path = request.url.path

        request_id = str(uuid.uuid4())
        request_data = await self._capture_request_data(request)
        response = await call_next(request)

        endpoint = request.scope.get("endpoint")

        if route_path is None and hasattr(request.app, "routes"):
            for r in request.app.routes:
                if getattr(r, "endpoint", None) == endpoint:
                    route_path = getattr(r, "path", "unknown")
                    break

        route_name = endpoint.__name__ if endpoint else None

        # Exclude by endpoint identity and by path.
        if endpoint in EXCLUDED_PATHS or _path_excluded_from_integrity(route_path, self._config):
            logger.debug("dispatch: excluded path, skipping attestation")
            return response

        response.headers["X-EQTY-Request-ID"] = request_id
        response.headers["Access-Control-Expose-Headers"] = "X-EQTY-Request-ID"

        _, model_cid, model_name = self._resolve_model(request.app)

        if 200 <= response.status_code < 300:
            if isinstance(response, StreamingResponse) or hasattr(response, 'body_iterator'):
                logger.debug("dispatch: Streaming")
                original_iterator = response.body_iterator
                source = self._endpoint_source(endpoint)

                async def logging_iterator():
                    chunks = []
                    async for chunk in original_iterator:
                        chunks.append(chunk)
                        yield chunk

                    try:
                        combined_body = b''.join(chunks)
                        response_body = self._process_body(combined_body)
                    except Exception as e:
                        logger.warning(f"Failed to process streaming chunks: {str(e)}")
                        response_body = "<failed_to_process_streaming_content>"

                    response_data = {
                        "status_code": response.status_code,
                        "headers": dict(response.headers),
                        "body": response_body,
                    }

                    log_entry = self._build_log_entry(
                        request_id, request_data, response_data, source,
                        route_name, route_path, endpoint,
                    )
                    self._writer.enqueue(request_id, log_entry, model_cid, model_name)

                # Wrap the iterator in place rather than rebuilding the response,
                # so the original response object - its class, headers, media
                # type and .background cleanup task - is preserved.
                response.body_iterator = logging_iterator()
                return response

            response_data = await self._capture_response_data(response)
            source = self._endpoint_source(endpoint)

            log_entry = self._build_log_entry(
                request_id, request_data, response_data, source,
                route_name, route_path, endpoint,
            )
            self._writer.enqueue(request_id, log_entry, model_cid, model_name)

        return response

    async def _capture_request_data(self, request: Request) -> dict:
        headers = dict(request.headers)
        path_params = dict(request.path_params)
        query_params = dict(request.query_params)
        endpoint = request.scope.get("endpoint")
        endpoint_name = endpoint.__name__ if endpoint else None
        endpoint_module = endpoint.__module__ if endpoint else None
        body_bytes = await request.body()
        decoded_body = self._process_body(body_bytes)

        return {
            "method": request.method,
            "url": str(request.url),
            "headers": headers,
            "path_params": path_params,
            "query_params": query_params,
            "body": decoded_body,
            "endpoint": {"name": endpoint_name, "module": endpoint_module},
        }

    def _process_body(self, combined_body: bytes) -> Any:
        # bound what we retain so an oversize body can't OOM the worker.
        cap = self._config.max_body_bytes
        if cap and len(combined_body) > cap:
            logger.warning(
                f"body of {len(combined_body)} bytes exceeds "
                f"EQTY_MIDDLEWARE_MAX_BODY_BYTES={cap}; storing size-only placeholder"
            )
            return {"_truncated": True, "size": len(combined_body)}
        if not self._config.json_body:
            # exact wire bytes, base64-wrapped, so the body CID matches the raw payload
            return base64.b64encode(combined_body).decode('ascii')
        try:
            decoded_body = combined_body.decode('utf-8')
            try:
                return json.loads(decoded_body)
            except json.JSONDecodeError:
                return decoded_body
        except UnicodeDecodeError:
            if len(combined_body) < 2000:
                return {
                    "_base64": True,
                    "data": base64.b64encode(combined_body).decode('ascii'),
                    "size": len(combined_body),
                }
            return f"<binary data: {len(combined_body)} bytes>"

    async def _capture_response_data(self, response: Response) -> dict:
        response_data = {
            "status_code": response.status_code,
            "headers": dict(response.headers),
        }
        if isinstance(response, StreamingResponse) or hasattr(response, "body_iterator"):
            try:
                chunks = []
                async for chunk in response.body_iterator:
                    chunks.append(chunk)
                # restore a consumable iterator. The old `iter(chunks)`
                # assigned a *sync* iterator onto an async body_iterator, so the
                # next `async for` raised TypeError and capture silently broke.
                async def _replay():
                    for c in chunks:
                        yield c
                response.body_iterator = _replay()
                combined_body = b''.join(chunks)
                response_data["body"] = self._process_body(combined_body)
            except Exception as e:
                logger.warning(f"Failed to capture streaming response: {str(e)}")
                response_data["body"] = "<streaming_response_error>"
        elif hasattr(response, 'body') and response.body:
            response_data["body"] = self._process_body(response.body)
        else:
            response_data["body"] = None
        return response_data
