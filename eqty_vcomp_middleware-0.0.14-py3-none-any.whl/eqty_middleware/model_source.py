"""Model-discovery helpers shared by init-time registration and per-request
dispatch, so the two can't drift. Workload-agnostic except for the
vLLM (``app.state.openai_serving_models``) and NIM (env var) entry points."""
import logging
import os
from typing import Optional

logger = logging.getLogger(__name__)


def _to_ci_glob(pattern: str) -> str:
    """Convert a glob pattern's letters to case-insensitive [Aa] character classes.
    Glob metacharacters (*, ?, [, ]) and path separators are left untouched."""
    out = []
    i = 0
    while i < len(pattern):
        ch = pattern[i]
        if ch == "[":
            j = pattern.find("]", i)
            if j == -1:
                out.append(pattern[i:])
                break
            out.append(pattern[i:j + 1])
            i = j + 1
            continue
        if ch.isalpha():
            out.append(f"[{ch.lower()}{ch.upper()}]")
        else:
            out.append(ch)
        i += 1
    return "".join(out)


def _hf_snapshot_dir_from_config(model_name):
    """Locate a partially-downloaded HF snapshot by a file vLLM always caches.

    ``snapshot_download(local_files_only=True)`` raises when the cached snapshot
    is incomplete, which is the normal case: vLLM fetches only the weights,
    config and tokenizer it needs, never the full repo. The model directory is
    still the parent of ``config.json`` in the cache, so resolve it directly -
    no complete snapshot required, and no network."""
    try:
        from huggingface_hub import try_to_load_from_cache
    except Exception:
        return None
    for fname in ("config.json", "params.json"):
        try:
            hit = try_to_load_from_cache(repo_id=model_name, filename=fname)
        except Exception:
            continue
        if isinstance(hit, str) and os.path.isfile(hit):
            return os.path.dirname(hit)
    return None


def get_hf_path_from_name(model_name):
    from huggingface_hub import snapshot_download
    try:
        model_path = snapshot_download(repo_id=model_name, local_files_only=True)
    except Exception as e:
        # vLLM caches only the weights/config it needs, not the whole repo, so
        # local_files_only raises on an otherwise-usable partial snapshot. Fall
        # back to the dir holding a file vLLM always caches before giving up.
        # (The NIM/NGC layout is handled separately by locate_nim_snapshot_dir.)
        logger.info(f"HF snapshot lookup failed for {model_name}: {e}")
        model_path = _hf_snapshot_dir_from_config(model_name)
    if model_path and os.path.isdir(model_path):
        logger.info(f"Found model {model_name} at {model_path}")
        return model_path
    logger.info(f"Not found model {model_name}")
    return None


def _served_model_name(app) -> Optional[str]:
    """Name of the model the wrapped app is currently serving.

    Single source of truth shared by init-time discovery and per-request
    dispatch so the two can't drift. vLLM exposes it on
    ``app.state.openai_serving_models``; NIMs export it via env.
    """
    state = getattr(app, "state", None)
    handler = getattr(state, "openai_serving_models", None) if state is not None else None
    if handler:
        try:
            return handler.model_name()
        except Exception as e:
            logger.debug(f"openai_serving_models.model_name() failed: {e}")
            return None
    return os.environ.get("NIM_SERVED_MODEL_NAME") or os.environ.get("NIM_MODEL_NAME")


def locate_nim_snapshot_dir(model_name: str) -> Optional[str]:
    """Find the directory containing the model's weights for a NIM image.

    NIM caches model files under several layouts depending on the publisher.
    The path components don't always match ``NIM_SERVED_MODEL_NAME``
    byte-for-byte (e.g. served ``mistral/…`` vs NGC org ``mistralai/…``), so we
    search a few candidate locations and use the first one that contains files.
    """
    import glob

    cache_path = os.environ.get("NIM_CACHE_PATH") or "/opt/nim/.cache"
    model_name_hf = model_name.replace("/", "--")
    model_basename = model_name.split("/")[-1]

    # NGC paths are lowercase (e.g. ngc://nim/qwen/qwen3.6-27b) but
    # NIM_MODEL_NAME often uses HF casing (e.g. Qwen/Qwen3.6-27B). Match
    # both so patterns 1 & 2 are useful when more than one model is cached
    # under .cache/ngc/hub.
    def _ci_glob(pattern: str):
        return glob.glob(_to_ci_glob(pattern))

    candidates = []
    # 1. Exact heuristic: NIM_SERVED_MODEL_NAME → models--nim--<a>--<b>
    candidates += sorted(_ci_glob(
        f"{cache_path}/ngc/hub/models--nim--{model_name_hf}/snapshots/*"
    ))
    # 2. Same basename, different NGC org (e.g. mistralai vs mistral)
    candidates += sorted(_ci_glob(
        f"{cache_path}/ngc/hub/models--nim--*--{model_basename}/snapshots/*"
    ))
    # 3. Any snapshot dir under the cache (fallback for single-model NIMs)
    candidates += sorted(glob.glob(
        f"{cache_path}/ngc/hub/models--*/snapshots/*"
    ))
    # 4. Runtime-only location used by some TRT-LLM NIMs
    candidates += sorted(glob.glob("/tmp/LLM-*"))

    seen = set()
    for c in candidates:
        if c in seen:
            continue
        seen.add(c)
        if os.path.isdir(c) and any(os.scandir(c)):
            return c
    return None
