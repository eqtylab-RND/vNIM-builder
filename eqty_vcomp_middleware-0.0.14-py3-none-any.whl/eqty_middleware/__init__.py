import logging

# Attach a NullHandler to the package logger so records propagate to whatever the
# host application configured; the library never calls logging.basicConfig.
logging.getLogger(__name__).addHandler(logging.NullHandler())
