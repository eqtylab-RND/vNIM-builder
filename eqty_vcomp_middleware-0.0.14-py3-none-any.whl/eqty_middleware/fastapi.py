"""Backward-compatible facade for the split package.

The integration contract is ``from eqty_middleware.fastapi import IntegrityFastAPI``
(used by vllm.patch and every consumer), so this module re-exports the public API
plus the internals the test-suite imports. Implementation now lives in:
``config`` (Config), ``model_source`` (discovery), ``manifest_writer``
(_ManifestWriter + Document helpers), ``middleware`` (IntegrityFastAPI).
"""
import inspect  # noqa: F401  (tests monkeypatch the shared stdlib inspect.getsource)

from eqty_sdk import Context  # noqa: F401  (tests pass fa.Context to the helpers)

from .config import Config
from .manifest_writer import (
    _ManifestWriter,
    _asset_from_value,
    _document_from_collection,
)
from .model_source import (
    _served_model_name,
    _to_ci_glob,
    get_hf_path_from_name,
    locate_nim_snapshot_dir,
)
from .middleware import (
    DEFAULT_VCOMP_COCO_NOTARY_URL,
    DEFAULT_VCOMP_CRT_NOTARY_URL,
    EXCLUDED_PATHS,
    IntegrityFastAPI,
    _path_excluded_from_integrity,
    eqty_exclude_from_integrity,
)

__all__ = [
    "Config",
    "Context",
    "DEFAULT_VCOMP_COCO_NOTARY_URL",
    "DEFAULT_VCOMP_CRT_NOTARY_URL",
    "EXCLUDED_PATHS",
    "IntegrityFastAPI",
    "_ManifestWriter",
    "_asset_from_value",
    "_document_from_collection",
    "_path_excluded_from_integrity",
    "_served_model_name",
    "_to_ci_glob",
    "eqty_exclude_from_integrity",
    "get_hf_path_from_name",
    "locate_nim_snapshot_dir",
]
