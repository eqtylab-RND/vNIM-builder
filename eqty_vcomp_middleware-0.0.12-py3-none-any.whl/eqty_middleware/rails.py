"""GuardrailRails - NeMo-native guarded turn with in-process EQTY integrity.

NeMo runs the input rails and the streaming output rails; generation is a
direct multimodal passthrough to the attested model server (NeMo's own
generation flattens the conversation to text-only and would drop images).
This class instruments the turn in-process: the effective policy dir is
hashed into the exchange manifest as its CID (deploy = attest); the client
gets a real token stream, accumulated so a mid-stream block attests the
delivered prefix, not all-or-nothing; the inference manifest is located via
the ``X-EQTY-Request-ID`` response header (captured by an httpx hook on the
langchain client) and imported; the judge model CID and both notary DID
registrations are folded in, so one manifest verifies stand-alone.

Verified against nemoguardrails==0.23.0: ``stream_async(generator=...)``
applies output rails over an external generator without re-generating; an
output-rail block arrives in-stream as one JSON chunk ``{"error": {...}}``
with ``code: content_blocked``, then the stream ends; with
``stream_first: false`` tokens are only released after passing the output
rails; input rails run via ``check_async`` for a clean verdict;
``LLMRails(config, llm=...)`` makes the self-check rails call the served model.
"""
import asyncio
import contextvars
import json
import logging
import os
import uuid
from pathlib import Path
from typing import AsyncIterator, List, Optional

from .config import Config
from .guardrail import GuardrailAttestor

logger = logging.getLogger(__name__)

# Per-turn capture of X-EQTY-Request-ID headers seen by the model-server calls
# NeMo makes on our behalf (self-checks + generation). ContextVars propagate
# into the tasks stream_async spawns, so each turn sees only its own calls.
_TURN_CAPTURE: contextvars.ContextVar = contextvars.ContextVar(
    "eqty_turn_capture", default=None
)

REFUSAL_TEXT = "I'm sorry, I can't help with that."


def materialize_policy(policy_dir: str, work_dir: str) -> str:
    """Copy the logical policy files into a clean private directory and return
    its path. A Kubernetes ConfigMap mount is a symlink farm whose hidden
    entries (``..data/``, timestamped dirs) change on every apply even when the
    content doesn't - hashing the raw mount would make the policy CID unstable.
    """
    import shutil

    target = Path(work_dir) / "effective-policy"
    if target.exists():
        shutil.rmtree(target)
    target.mkdir(parents=True)
    for entry in sorted(os.listdir(policy_dir)):
        if entry.startswith("."):
            continue  # ..data / ..<timestamp> plumbing
        src = os.path.join(policy_dir, entry)
        if os.path.isfile(src):  # follows the CM symlinks
            shutil.copy(src, target / entry)
    if not any(target.iterdir()):
        raise ValueError(f"no policy files found in {policy_dir}")
    return str(target)


def parse_error_chunk(chunk) -> Optional[dict]:
    """NeMo 0.23 surfaces output-rail blocks and generation errors as a single
    in-stream chunk that is a full JSON object with an ``error`` key (normal
    chunks are small token strings). Returns the error dict, or None."""
    if not isinstance(chunk, str) or not chunk.startswith("{"):
        return None
    try:
        data = json.loads(chunk)
    except (json.JSONDecodeError, ValueError):
        return None
    if isinstance(data, dict) and isinstance(data.get("error"), dict):
        return data["error"]
    return None


class GuardedTurn:
    """One guarded exchange. ``chunks()`` yields exactly what the client should
    receive; after it finishes, ``result``/``output_verdict`` are populated and
    the exchange manifest (id = ``exchange_id``) has been queued for signing."""

    def __init__(self, exchange_id: str):
        self.exchange_id = exchange_id
        self.input_verdict: Optional[dict] = None
        self.output_verdict: Optional[dict] = None
        self.delivered: List[str] = []
        self.result: Optional[str] = None  # passed | input_blocked | output_blocked | error
        self.blocked_rail: Optional[str] = None

    @property
    def delivered_text(self) -> str:
        return "".join(self.delivered)


class GuardrailRails:
    """NeMo ``LLMRails`` wrapper + EQTY attestor for the guarded-turn path."""

    def __init__(
        self,
        policy_dir: str,
        log_directory: str,
        server_base: str,
        notary_did_url: Optional[str] = None,
        training_did_path: Optional[str] = None,
        notary_url: Optional[str] = None,
        config: Optional[Config] = None,
        llm_api_key: str = "any",
    ):
        # Import here so the base middleware package never requires NeMo.
        import httpx
        from langchain_openai import ChatOpenAI
        from nemoguardrails import LLMRails, RailsConfig

        self.server_base = server_base.rstrip("/")
        self._notary_did_url = notary_did_url
        # NeMo loads from, and the attestor hashes, this same materialized
        # copy, so "what was enforced" and "what was attested" can't diverge.
        self.policy_dir = materialize_policy(str(policy_dir), log_directory)
        self.attestor = GuardrailAttestor(
            log_directory, notary_url=notary_url, config=config,
            policy_dir=self.policy_dir,
        )

        self.rails_config = RailsConfig.from_path(self.policy_dir)
        main = next(
            (m for m in self.rails_config.models if m.type == "main"), None
        )
        if main is None:
            raise ValueError(f"policy at {self.policy_dir} has no models.main")
        params = dict(main.parameters or {})
        self.model_name = main.model
        self._llm_key = params.get("api_key", llm_api_key)
        self._model_url = params.get("base_url", f"{self.server_base}/v1").rstrip("/") + "/chat/completions"
        self._hooked_client = httpx.AsyncClient(
            timeout=600.0, event_hooks={"response": [self._capture_response]}
        )
        llm = ChatOpenAI(
            model=main.model,
            base_url=params.get("base_url", f"{self.server_base}/v1"),
            api_key=self._llm_key,
            temperature=params.get("temperature", 0.0),
            http_async_client=self._hooked_client,
            max_retries=1,
        )
        self.rails = LLMRails(self.rails_config, llm=llm)

        # One H100 + HF backend serialize generation anyway; a per-turn lock
        # keeps NeMo per-call state and header correlation unambiguous.
        self._turn_lock = asyncio.Lock()
        self._did_paths = self._collect_did_paths(training_did_path)

    def _collect_did_paths(self, training_did_path: Optional[str]) -> List[str]:
        paths = []
        if training_did_path and os.path.isfile(training_did_path):
            paths.append(str(training_did_path))
        elif training_did_path:
            logger.warning(f"training DID registration not found: {training_did_path}")
        snap = self._snapshot_serving_did()
        if snap:
            paths.append(snap)
        return paths

    def _snapshot_serving_did(self) -> Optional[str]:
        """Fetch the serving notary's DID registration once and keep it next to
        the manifests, so every exchange can embed it."""
        if not self._notary_did_url:
            return None
        import urllib.request

        target = Path(self.attestor.log_directory) / "serving-did-registration.json"
        try:
            with urllib.request.urlopen(self._notary_did_url, timeout=10) as r:
                data = json.loads(r.read())
            if not data.get("statements"):
                raise ValueError("no statements in DID registration")
            target.write_text(json.dumps(data))
            return str(target)
        except Exception as e:
            logger.warning(f"serving DID registration snapshot failed: {e}")
            return None

    async def _capture_response(self, response):
        capture = _TURN_CAPTURE.get()
        if capture is None:
            return
        rid = response.headers.get("x-eqty-request-id")
        if not rid:
            return
        try:
            is_generation = b'"stream": true' in response.request.content or \
                b'"stream":true' in response.request.content
        except Exception:
            is_generation = False
        capture.append({"rid": rid, "stream": is_generation})

    @staticmethod
    def _generation_rid(capture: List[dict]) -> Optional[str]:
        """The generation call is the streamed one; self-check calls are not.
        Fall back to the last captured id (non-streaming upstreams)."""
        for entry in reversed(capture):
            if entry["stream"]:
                return entry["rid"]
        return capture[-1]["rid"] if capture else None

    async def run_turn(
        self, messages: List[dict], raw_request: bytes, gen_params: Optional[dict] = None
    ) -> GuardedTurn:
        """Run input rails; on block, attest and finish. Otherwise the caller
        must iterate ``turn.chunks()`` (streams generation + output rails and
        finalizes the exchange manifest). ``gen_params`` carries the client's
        sampling knobs (temperature, max_tokens, top_p) for generation."""
        from nemoguardrails.rails.llm.options import RailStatus, RailType

        turn = GuardedTurn(str(uuid.uuid4()))
        # Bounded wait: a client vanishing between run_turn() and chunks()
        # must not leak the lock and hang every later turn forever.
        await asyncio.wait_for(self._turn_lock.acquire(), timeout=900)
        try:
            user_text = _last_user_text(messages)
            turn.input_verdict = {
                "stage": "input", "blocked": False, "status": "passed", "rail": None,
            }
            if user_text:
                capture: List[dict] = []
                token = _TURN_CAPTURE.set(capture)
                try:
                    res = await self.rails.check_async(
                        [{"role": "user", "content": user_text}],
                        rail_types=[RailType.INPUT],
                    )
                except Exception as e:
                    # FAIL-CLOSED: a rail-LLM failure blocks the turn and the
                    # failure itself is attested, never silently passed.
                    logger.error(f"input rail error (fail-closed): {e}")
                    turn.input_verdict = {
                        "stage": "input", "blocked": True, "status": "error",
                        "rail": "self check input", "reason": str(e)[:300],
                    }
                    turn.result = "error"
                    self._attest_input_block(turn, raw_request)
                    self._turn_lock.release()
                    return turn
                finally:
                    _TURN_CAPTURE.reset(token)
                turn.input_verdict = {
                    "stage": "input",
                    "blocked": res.status == RailStatus.BLOCKED,
                    "status": res.status.value,
                    "rail": res.rail,
                }
                if res.status == RailStatus.BLOCKED:
                    turn.result = "input_blocked"
                    turn.blocked_rail = res.rail or "input"
                    self._attest_input_block(turn, raw_request)
                    self._turn_lock.release()
                    return turn
            self._pending = (turn, messages, raw_request, gen_params or {})
            return turn
        except BaseException:
            self._turn_lock.release()
            raise

    def _attest_input_block(self, turn: GuardedTurn, raw_request: bytes):
        # _judge is written on the writer thread, read here on the event loop;
        # safe as an atomic, set-once reference read under CPython.
        judge = self.attestor._judge
        self.attestor.attest_block(
            request_body=raw_request,
            verdict=turn.input_verdict,
            model_cid=judge[0] if judge else None,
            model_name=judge[1] if judge else "Model",
            request_id=turn.exchange_id,
        )

    async def _model_stream(self, messages, gen_params=None) -> AsyncIterator[str]:
        """Stream tokens straight from the attested model server with the
        original messages (multimodal preserved) - NeMo's own generation would
        flatten images to a "[+ image]" placeholder. Uses the header-hooked
        client so X-EQTY-Request-ID is captured for the inference-manifest
        join; ``stream=true`` marks this as the generation call."""
        gp = gen_params or {}
        body = {
            "model": self.model_name,
            "messages": messages,
            "stream": True,
            # Default to 0.7, not the 0.0 the rail-check model uses: greedy
            # decoding makes the model repeat itself on long creative prompts.
            "temperature": gp.get("temperature") if gp.get("temperature") is not None else 0.7,
        }
        for k in ("max_tokens", "top_p", "presence_penalty", "frequency_penalty"):
            if gp.get(k) is not None:
                body[k] = gp[k]
        headers = {"authorization": f"Bearer {self._llm_key}", "content-type": "application/json"}
        async with self._hooked_client.stream(
            "POST", self._model_url, json=body, headers=headers
        ) as resp:
            resp.raise_for_status()
            async for line in resp.aiter_lines():
                if not line.startswith("data:"):
                    continue
                payload = line[5:].strip()
                if payload == "[DONE]":
                    break
                try:
                    delta = json.loads(payload)["choices"][0]["delta"].get("content")
                except (json.JSONDecodeError, KeyError, IndexError):
                    continue
                if delta:
                    yield delta

    async def chunks(self, turn: GuardedTurn) -> AsyncIterator[str]:
        """Stream the generation through NeMo's streaming output rails, yield
        exactly what the client receives, then finalize the exchange manifest.
        Must be called once, only for turns whose input rails passed."""
        pending = getattr(self, "_pending", None)
        assert pending and pending[0] is turn, "chunks() without matching run_turn()"
        self._pending = None
        _, messages, raw_request, gen_params = pending

        error: Optional[dict] = None
        capture: List[dict] = []
        token = _TURN_CAPTURE.set(capture)
        try:
            # NeMo drives the OUTPUT rails over our passthrough generator
            # (generator= bypasses NeMo's text-only re-generation, so images
            # survive); messages= gives the rails the user context.
            agen = self.rails.stream_async(
                messages=messages, generator=self._model_stream(messages, gen_params)
            )
            async for chunk in agen:
                err = parse_error_chunk(chunk)
                if err is not None:
                    error = err
                    break
                turn.delivered.append(chunk)
                yield chunk
        except Exception as e:
            logger.error(f"streaming turn failed (fail-closed): {e}")
            error = {"message": str(e)[:300], "code": "stream_failure"}
        finally:
            _TURN_CAPTURE.reset(token)
            self._finalize(turn, raw_request, error, capture)
            self._turn_lock.release()

    def _finalize(self, turn: GuardedTurn, raw_request: bytes,
                  error: Optional[dict], capture: List[dict]):
        if error is None:
            turn.result = "passed"
            turn.output_verdict = {
                "stage": "output", "blocked": False, "status": "passed", "rail": None,
            }
        elif error.get("code") == "content_blocked":
            turn.result = "output_blocked"
            turn.blocked_rail = error.get("param") or "output"
            turn.output_verdict = {
                "stage": "output", "blocked": True, "status": "blocked",
                "rail": turn.blocked_rail,
                # attest the truncation: how much of the intended generation
                # the client actually received before the cut
                "delivered_chunks": len(turn.delivered),
                "delivered_bytes": len(turn.delivered_text.encode("utf-8")),
                "truncated": True,
            }
        else:
            turn.result = "error"
            turn.blocked_rail = error.get("param")
            turn.output_verdict = {
                "stage": "output", "blocked": True, "status": "error",
                "rail": error.get("param"),
                "reason": (error.get("message") or "")[:300],
                "delivered_chunks": len(turn.delivered),
                "delivered_bytes": len(turn.delivered_text.encode("utf-8")),
            }
        rid = self._generation_rid(capture)
        inference_url = f"{self.server_base}/integrity/manifest/{rid}" if rid else None
        self.attestor.attest_streamed_exchange(
            request_id=turn.exchange_id,
            request_body=raw_request,
            input_verdict=turn.input_verdict,
            response_text=turn.delivered_text,
            output_verdict=turn.output_verdict,
            inference_manifest_url=inference_url,
            did_import_paths=self._did_paths,
        )

    def drain(self, timeout: Optional[float] = None):
        self.attestor.drain(timeout)


def _last_user_text(messages: List[dict]) -> str:
    for m in reversed(messages):
        if m.get("role") == "user":
            c = m.get("content")
            if isinstance(c, list):  # VL content blocks -> concat text parts
                return " ".join(
                    p.get("text", "") for p in c
                    if isinstance(p, dict) and p.get("type") == "text"
                )
            return c or ""
    return ""
