"""Model-discovery helpers shared by init-time registration and per-request
dispatch, so the two can't drift. Workload-agnostic except for the
vLLM (``app.state.openai_serving_models``) and NIM (env var) entry points."""
import logging
import os
from typing import Optional

logger = logging.getLogger(__name__)


def _to_ci_glob(pattern: str) -> str:
    """Convert a glob pattern's letters to case-insensitive [Aa] character classes.
    Glob metacharacters (*, ?, [, ]) and path separators are left untouched."""
    out = []
    i = 0
    while i < len(pattern):
        ch = pattern[i]
        if ch == "[":
            j = pattern.find("]", i)
            if j == -1:
                out.append(pattern[i:])
                break
            out.append(pattern[i:j + 1])
            i = j + 1
            continue
        if ch.isalpha():
            out.append(f"[{ch.lower()}{ch.upper()}]")
        else:
            out.append(ch)
        i += 1
    return "".join(out)


def locate_hf_snapshot_dir(model_name: str) -> Optional[str]:
    """Resolve the model's snapshot dir straight from the HF cache layout.

    vLLM downloads only the files it serves (weights, config, tokenizer) and
    skips e.g. README.md / LICENSE / .gitattributes, so ``snapshot_download(
    local_files_only=True)`` raises IncompleteSnapshotError on a perfectly
    servable cache. Registering only the downloaded files is correct for
    attestation anyway — those are exactly the bytes being served.
    """
    import glob

    from huggingface_hub.constants import HF_HUB_CACHE  # honors HF_HOME etc.

    pattern = f"{HF_HUB_CACHE}/models--{model_name.replace('/', '--')}/snapshots/*"
    for c in sorted(glob.glob(pattern)):
        if os.path.isdir(c) and any(os.scandir(c)):
            return c
    return None


def get_hf_path_from_name(model_name):
    from huggingface_hub import snapshot_download
    try:
        model_path = snapshot_download(repo_id=model_name, local_files_only=True)
    except Exception as e:
        # Raised for partial downloads (vLLM never fetches README/LICENSE →
        # IncompleteSnapshotError) or when the model is cached in NIM's NGC
        # layout instead of HF. Fall back to reading the cache layout directly
        # before giving up.
        logger.info(f"HF snapshot lookup failed for {model_name}: {e}")
        model_path = locate_hf_snapshot_dir(model_name)
        if model_path:
            logger.info(f"Found model {model_name} via cache layout at {model_path}")
        return model_path
    if os.path.isdir(model_path):
        logger.info(f"Found model {model_name} at {model_path}")
        return model_path
    logger.info(f"Not found model {model_name} at {model_path}")
    return None


def _served_model_name(app) -> Optional[str]:
    """Name of the model the wrapped app is currently serving.

    Single source of truth shared by init-time discovery and per-request
    dispatch so the two can't drift. vLLM exposes it on
    ``app.state.openai_serving_models``; NIMs export it via env.
    """
    state = getattr(app, "state", None)
    handler = getattr(state, "openai_serving_models", None) if state is not None else None
    if handler:
        try:
            return handler.model_name()
        except Exception as e:
            logger.debug(f"openai_serving_models.model_name() failed: {e}")
            return None
    return os.environ.get("NIM_SERVED_MODEL_NAME") or os.environ.get("NIM_MODEL_NAME")


def locate_nim_snapshot_dir(model_name: str) -> Optional[str]:
    """Find the directory containing the model's weights for a NIM image.

    NIM caches model files under several layouts depending on the publisher.
    The path components don't always match ``NIM_SERVED_MODEL_NAME``
    byte-for-byte (e.g. served ``mistral/…`` vs NGC org ``mistralai/…``), so we
    search a few candidate locations and use the first one that contains files.
    """
    import glob

    cache_path = os.environ.get("NIM_CACHE_PATH") or "/opt/nim/.cache"
    model_name_hf = model_name.replace("/", "--")
    model_basename = model_name.split("/")[-1]

    # NGC paths are lowercase (e.g. ngc://nim/qwen/qwen3.6-27b) but
    # NIM_MODEL_NAME often uses HF casing (e.g. Qwen/Qwen3.6-27B). Match
    # both so patterns 1 & 2 are useful when more than one model is cached
    # under .cache/ngc/hub.
    def _ci_glob(pattern: str):
        return glob.glob(_to_ci_glob(pattern))

    candidates = []
    # 1. Exact heuristic: NIM_SERVED_MODEL_NAME → models--nim--<a>--<b>
    candidates += sorted(_ci_glob(
        f"{cache_path}/ngc/hub/models--nim--{model_name_hf}/snapshots/*"
    ))
    # 2. Same basename, different NGC org (e.g. mistralai vs mistral)
    candidates += sorted(_ci_glob(
        f"{cache_path}/ngc/hub/models--nim--*--{model_basename}/snapshots/*"
    ))
    # 3. Any snapshot dir under the cache (fallback for single-model NIMs)
    candidates += sorted(glob.glob(
        f"{cache_path}/ngc/hub/models--*/snapshots/*"
    ))
    # 4. Runtime-only location used by some TRT-LLM NIMs
    candidates += sorted(glob.glob("/tmp/LLM-*"))

    seen = set()
    for c in candidates:
        if c in seen:
            continue
        seen.add(c)
        if os.path.isdir(c) and any(os.scandir(c)):
            return c
    return None
