import json
import logging
import os
from enum import Enum
from os import PathLike, fspath
from pathlib import Path
from typing import Any, Generic, Optional, TypeVar, Union, cast

from eqty_sdk._rust import (
    CID,
    Context,
    get_cid_for_bytes,
    get_cid_for_path,
)
from eqty_sdk.context import get_active_context
from eqty_sdk.declaration import Declaration
from eqty_sdk.metadata import Metadata
from eqty_sdk.statements import (
    add_data_statement,
    add_governance_statement,
    add_metadata_statement,
    add_model_signing_statement,
)

logger = logging.getLogger("eqty.sdk.Asset")

AssetT = TypeVar("AssetT", bound="Asset")
TypedAssetT = TypeVar("TypedAssetT", bound="TypedAsset[Any]")


# This determines the icon that is used on the graph.
# These are the 'known' types, but actual value can be anything
class AssetType(Enum):
    AGENT = "Agent"
    BENCHMARK = "Benchmark"
    BENCHMARK_RESULT = "Benchmark_Result"
    BINARY = "Binary"
    CERTIFICATE = "Certificate"
    CODE = "Code"
    CONFIGURATION = "Configuration"
    CREDENTIAL = "Credential"
    CUSTOM = "Custom"
    DATABASE = "Database"
    DATASET = "Dataset"
    DOCUMENT = "Document"
    GUARDRAIL = "Guardrail"
    MEDIA = "Media"
    MODEL = "Model"
    PROMPT = "Prompt"
    REASONING = "Reasoning"
    SKILL = "Skill"
    SYSTEM_PROMPT = "System_Prompt"
    TOKEN = "Token"
    TOOL = "Tool"


def _init_path_input(path: Union[str, PathLike[str]]) -> Path:
    """Gets the resolved Path."""
    return Path(fspath(path)).resolve()


def serialize_for_hashing(obj: Any) -> bytes:
    """Serializes the object to a format suitable for hashing based on its type."""
    if isinstance(obj, str):
        return obj.encode("utf-8")  # Encode strings
    elif isinstance(obj, (int, float)):
        return str(obj).encode("utf-8")  # Encode numbers as strings
    elif isinstance(obj, list) or isinstance(obj, dict):
        return json.dumps(obj).encode("utf-8")  # JSON-encode complex data structures
    elif isinstance(obj, (Path, os.PathLike)):
        return os.fspath(obj).encode("utf-8")
    elif hasattr(obj, "serialize_for_hashing"):  # Check for custom implementation
        return cast(bytes, obj.serialize_for_hashing())
    elif hasattr(obj, "model"):
        # Serialize model state dict to JSON if available
        state_dict = getattr(obj, "model").state_dict()
        try:
            return json.dumps(state_dict).encode("utf-8")
        except (TypeError, ValueError) as e:
            raise TypeError(f"Unsupported model state dict for hashing: {type(state_dict)} - {e}")
    elif hasattr(obj, "__dict__"):
        try:
            return json.dumps(obj.__dict__).encode("utf-8")
        except (TypeError, ValueError) as e:
            raise TypeError(f"Unsupported __dict__ for hashing: {type(obj)} - {e}")
    # Add more cases for other data types as needed
    else:
        raise TypeError(f"Unsupported data type for hashing: {type(obj)}")


def get_asset_name(asset_type: Union[AssetType, str], cid: CID) -> str:
    cid_suffix = str(cid)[-4:]
    if isinstance(asset_type, AssetType):
        return f"{asset_type.value}-{cid_suffix}"
    else:
        return f"{asset_type}-{cid_suffix}"


class Asset:
    def __init__(
        self,
        obj: Any,
        asset_type: Union[AssetType, str],
        cid: CID,
        is_dir: bool,
        custom_ctx: Optional[Context],
        **kwargs,
    ):
        if custom_ctx:
            logger.info(f"Creating asset with custom context: {custom_ctx}")
        self._ctx = custom_ctx

        self._value: Any = obj
        self._skip_proof = kwargs.pop("_skip_proof", None)
        self._enable_model_signing_signature = kwargs.pop("_enable_model_signing_signature", False)

        self._cid = cid
        self._is_dir = is_dir
        self.statement_ids: list[CID] = []

        if isinstance(asset_type, AssetType):
            kwargs.update({"assetType": asset_type.value})
        else:
            kwargs.update({"assetType": asset_type})

        self._metadata = Metadata(**kwargs)

        if not kwargs.get("skip_registration", False):
            try:
                self._create_eqty_statements()

            except RuntimeError as e:
                logger.error(f"Error creating new asset: {e}")
                raise e

    @classmethod
    def _from_object(
        cls: type[AssetT],
        obj: Any,
        asset_type: Union[AssetType, str],
        ctx: Optional[Context] = None,
        _store: Optional[bool] = None,
        **kwargs,
    ) -> AssetT:
        ctx = ctx or get_active_context()
        serialized_bytes = serialize_for_hashing(obj)
        cid = get_cid_for_bytes(serialized_bytes, _store)
        kwargs.setdefault("name", get_asset_name(asset_type, cid))

        asset = cls(obj, asset_type, cid, is_dir=False, custom_ctx=ctx, **kwargs)
        return asset

    @classmethod
    def _from_path(
        cls: type[AssetT],
        path: Union[str, PathLike[str]],
        asset_type: Union[AssetType, str],
        ctx: Optional[Context] = None,
        _store: Optional[bool] = None,
        **kwargs,
    ) -> AssetT:
        ctx = ctx or get_active_context()
        resolved_path = _init_path_input(path)
        cid = get_cid_for_path(resolved_path, _store)
        is_dir = resolved_path.is_dir()
        kwargs.setdefault("name", get_asset_name(asset_type, cid))

        asset = cls(resolved_path, asset_type, cid, is_dir, custom_ctx=ctx, **kwargs)
        return asset

    @classmethod
    def _from_cid(
        cls: type[AssetT],
        cid: CID,
        asset_type: Union[AssetType, str],
        ctx: Optional[Context] = None,
        **kwargs,
    ) -> AssetT:
        ctx = ctx or get_active_context()
        kwargs.setdefault("name", get_asset_name(asset_type, cid))

        asset = cls(cid, asset_type, cid, is_dir=False, custom_ctx=ctx, **kwargs)
        return asset

    @classmethod
    def _factory_with_context(cls: type[AssetT], ctx: Context, asset_type: Union[AssetType, str]):
        class _Factory:
            def from_path(self, path: PathLike, _store: Optional[bool] = None, **kwargs) -> AssetT:
                return cls._from_path(path, asset_type, ctx, _store, **kwargs)

            def from_cid(self, cid: CID, **kwargs) -> AssetT:
                return cls._from_cid(cid, asset_type, ctx, **kwargs)

            def from_object(self, obj: Any, _store: Optional[bool] = None, **kwargs) -> AssetT:
                return cls._from_object(obj, asset_type, ctx, _store, **kwargs)

        return _Factory()

    @property
    def name(self) -> str:
        """Get the name of the asset."""
        return cast(str, self._metadata.name)

    @property
    def cid(self) -> CID:
        """Get the CID of the asset."""
        return self._cid

    @property
    def asset_type(self) -> str:
        """Get the type of the asset."""
        return self._metadata._additional_metadata.get("assetType") or ""

    @property
    def value(self) -> Any:
        """Get the underlying value."""
        return self._value

    def add_declaration(self, declaration: Declaration) -> "Asset":
        document_cid = declaration.cid()
        ids = add_governance_statement(
            str(self.cid),
            str(document_cid),
            _skip_proof=self._skip_proof,
            context=self._ctx,
        )
        self.statement_ids.extend(ids)
        return self

    def _create_eqty_statements(self) -> None:
        """Creates DataStatement, MetadataStatement, and VcStatement."""
        self.statement_ids.extend(
            add_data_statement([self.cid], _skip_proof=self._skip_proof, context=self._ctx)
        )
        self.statement_ids.extend(
            add_metadata_statement(
                str(self.cid),
                self._metadata.to_json_str(),
                _skip_proof=self._skip_proof,
                context=self._ctx,
            )
        )

        if (
            self.asset_type == AssetType.MODEL.value
            and self._is_dir
            and self._enable_model_signing_signature
        ):
            collection_cid = self._cid.cid
            try:
                add_model_signing_statement(
                    collection_cid=collection_cid,
                    model_signing_name=self.name,
                    context=self._ctx,
                )
            except RuntimeError as exc:
                message = str(exc)
                if message.startswith("Unsupported multicodec for public key"):
                    logger.warning(
                        "Skipping model signing statement for '%s': "
                        "The active signer must be of type SECP256R1 to use model signing",
                        self.name,
                    )
                else:
                    raise

    def __repr__(self) -> str:
        return f"Asset({self._value!r})"

    def __str__(self) -> str:
        return cast(str, self._value.__str__())

    def __getattr__(self, key):
        logger.info(f"Getting key: {key}")
        # Handle specific attributes directly
        if key in {"asset_type", "cid", "name", "value", "add_attribute"}:
            return object.__getattribute__(self, key)

        # Attempt to get the attribute from the wrapped object
        try:
            return getattr(self._value, key)
        except AttributeError:
            # Check the _metadata dictionary if the key is not found
            if key in self._metadata:
                return self._metadata[key]
            else:
                raise AttributeError(
                    f"'{type(self._value).__name__}' object has no attribute '{key}'"
                )

    def __setattr__(self, key, value):
        # logger.info(f"Setting key: {key}")
        # Special handling to set attributes on the wrapper, not the wrapped object
        if key in {
            "_ctx",
            "_value",
            "_name",
            "_cid",
            "_is_dir",
            "_metadata",
            "_asset_type",
            "_skip_proof",
            "_enable_model_signing_signature",
            "statement_ids",
        }:
            object.__setattr__(self, key, value)
        else:
            setattr(self._value, key, value)

    def __getitem__(self, key):
        # Delegate indexing to the wrapped object
        return self._value[key]

    def __setitem__(self, key, value):
        # Delegate item assignment to the wrapped object
        self._value[key] = value

    def __hash__(self):
        return hash(self._value)

    def __iter__(self):
        try:
            # Try to delegate iteration to the wrapped object
            return iter(self._value)
        except TypeError:
            raise TypeError(f"{type(self._value).__name__} object is not iterable")


class TypedAsset(Asset, Generic[AssetT]):
    """Base class for typed assets. Subclasses just need to set _asset_type class variable."""

    _asset_type: AssetType

    @classmethod
    def from_path(
        cls: type[TypedAssetT],
        path: Union[str, PathLike[str]],
        _store: Optional[bool] = None,
        **kwargs,
    ) -> TypedAssetT:
        """Create and register this asset type from a file or directory path."""
        return cls._from_path(path, cls._asset_type, _store=_store, **kwargs)

    @classmethod
    def from_cid(cls: type[TypedAssetT], cid: CID, **kwargs) -> TypedAssetT:
        """Create and register this asset type from an existing content identifier."""
        return cls._from_cid(cid, cls._asset_type, **kwargs)

    @classmethod
    def from_object(
        cls: type[TypedAssetT], obj: Any, _store: Optional[bool] = None, **kwargs
    ) -> TypedAssetT:
        """Create and register this asset type from an in-memory Python object."""
        return cls._from_object(obj, cls._asset_type, _store=_store, **kwargs)

    @classmethod
    def with_context(cls: type[TypedAssetT], ctx: Context) -> Any:
        """Return factory methods that register this asset in ``ctx``."""
        return cls._factory_with_context(ctx, cls._asset_type)

    def __len__(self):
        try:
            # Try to get the length of the wrapped object
            return len(self._value)
        except TypeError:
            raise TypeError(f"{type(self._value).__name__} object has no len()")

    def __eq__(self, other):
        """Check if two Asset objects are equal based on their underlying values."""
        if not isinstance(other, Asset):
            if self._value is None and other is None:
                return True
            if self._value is None or other is None:
                return False
            return self._value == other
        if self._value is None and other._value is None:
            return True
        if self._value is None or other._value is None:
            return False
        return self._value == other._value

    def __add__(self, other):
        """Overload the + operator to support adding Asset objects if their underlying types are compatible,
        otherwise fallback to delegating to the underlying value.
        """
        try:
            if (
                isinstance(self._value, list)
                and isinstance(other, Asset)
                and isinstance(other._value, list)
            ):
                # If both underlying values are lists, add them directly
                return self._value + other._value
            elif isinstance(other, Asset):
                return self._value + other._value
            else:
                # Delegate addition to the underlying value if possible
                return self._value + other
        except TypeError:
            # Raise specific error if addition fails entirely
            raise TypeError("Cannot add Asset objects together")

    def __mul__(self, other):
        """Overload the * operator to potentially support multiplication of Asset objects
        based on the underlying value's behavior.
        """
        try:
            if isinstance(other, (int, float)) and isinstance(self._value, (int, float)):
                # If both are numbers, multiply them directly
                return self._value * other
            elif isinstance(other, Asset):
                return self._value * other._value
            else:
                # Delegate multiplication to the underlying value if possible
                return self._value * other
        except TypeError:
            # Raise specific error if multiplication fails entirely
            raise TypeError(f"Unsupported operand types for *: 'Asset' and '{type(other)}'")

    def __truediv__(self, other):
        """Overload the / operator to potentially support division of Asset objects
        based on the underlying value's behavior.
        """
        try:
            if isinstance(other, (int, float)) and isinstance(self._value, (int, float)):
                # If both are numbers, divide them directly
                return self._value / other
            elif isinstance(other, Asset):
                return self._value / other._value
            else:
                # Delegate division to the underlying value if possible
                return self._value / other
        except TypeError:
            # Raise specific error if division fails entirely
            raise TypeError(f"Unsupported operand types for /: 'Asset' and '{type(other)}'")

    def __floordiv__(self, other):
        """Overload the // operator to potentially support floor division of Asset objects
        based on the underlying value's behavior.
        """
        try:
            if isinstance(other, (int, float)) and isinstance(self._value, (int, float)):
                # If both are numbers, divide them directly
                return self._value // other
            elif isinstance(other, Asset):
                return self._value // other._value
            else:
                # Delegate floor division to the underlying value if possible
                return self._value // other
        except TypeError:
            # Raise specific error if floor division fails entirely
            raise TypeError(f"Unsupported operand types for //: 'Asset' and '{type(other)}'")

    def __mod__(self, other):
        """Overload the % operator to potentially support modulo of Asset objects
        based on the underlying value's behavior.
        """
        try:
            if isinstance(other, (int, float)) and isinstance(self._value, (int, float)):
                # If both are numbers, divide them directly
                return self._value % other
            elif isinstance(other, Asset):
                return self._value % other._value
            else:
                # Delegate modulo to the underlying value if possible
                return self._value % other
        except TypeError:
            # Raise specific error if modulo fails entirely
            raise TypeError(f"Unsupported operand types for %: 'Asset' and '{type(other)}'")

    def __pow__(self, other):
        """Overload the ** operator to potentially support exponentiation of Asset objects
        based on the underlying value's behavior.
        """
        try:
            if isinstance(other, (int, float)) and isinstance(self._value, (int, float)):
                # If both are numbers, divide them directly
                return self._value**other
            elif isinstance(other, Asset):
                return self._value**other._value
            else:
                # Delegate exponentiation to the underlying value if possible
                return self._value**other
        except TypeError:
            # Raise specific error if exponentiation fails entirely
            raise TypeError(f"Unsupported operand types for **: 'Asset' and '{type(other)}'")

    def __sub__(self, other):
        """Overload the - operator to potentially support subtraction of Asset objects
        based on the underlying value's behavior.
        """
        try:
            if isinstance(other, (int, float)) and isinstance(self._value, (int, float)):
                # If both are numbers, subtract them directly
                return self._value - other
            elif isinstance(other, Asset):
                return self._value - other._value
            else:
                # Delegate subtraction to the underlying value if possible
                return self._value - other
        except TypeError:
            # Raise specific error if subtraction fails entirely
            raise TypeError(f"Unsupported operand types for -: 'Asset' and '{type(other)}'")
