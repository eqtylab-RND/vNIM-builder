"""Optional cuAttest transport and request-window evidence (no CUDA in API process)."""
import asyncio
import copy
import json
import sys
from pathlib import Path


def monitoring_client(url, model_name, model_cid, interval_ms, timeout=600):
    # Lazy optional dependency: ordinary installations never import cuattest.
    from cuattest.client import Client

    class MonitoringClient(Client):
        def _rpc(self, path, body=None):
            if path == "/v1/registrations/sign":
                raise RuntimeError("the notary owns the scan schedule")
            if path == "/v1/registrations/import":
                body = {**body, "model": model_name, "model_cid": model_cid,
                        "interval_ms": interval_ms, "immutable_until_close": True}
            return super()._rpc(path.replace("/v1/", "/v1/gpu/", 1), body)

    return MonitoringClient(url, timeout=timeout)


def merge_manifests(*manifests):
    """Preserve exact signed JSON; reject conflicting content-addressed entries."""
    result = {"version": "3", "contexts": {}, "statements": {}, "blobs": {}}
    for manifest in manifests:
        if manifest.get("version") != "3":
            raise ValueError("cuAttest requires manifest version 3")
        if set(manifest) - {"version", "contexts", "statements", "blobs", "anchors"}:
            raise ValueError("unsupported manifest fields")
        for section in ("contexts", "statements", "blobs"):
            for key, value in manifest.get(section, {}).items():
                if key in result[section] and result[section][key] != value:
                    raise ValueError(f"conflicting manifest {section}: {key}")
                result[section][key] = copy.deepcopy(value)
        for anchor in manifest.get("anchors", []):
            if anchor not in result.setdefault("anchors", []):
                result["anchors"].append(copy.deepcopy(anchor))
    return result


def attach_manifest(path, evidence):
    path = Path(path)
    exported = json.loads(path.read_text())
    # SDK 2.3 serializes singleton evidence.type arrays as strings. Restore
    # the original notary representation only when this is the sole difference;
    # proof bytes and every other field must still match exactly.
    for key, original in evidence.get("statements", {}).items():
        current = exported.get("statements", {}).get(key)
        if current is not None and current != original:
            if _evidence_type_arrays(current) == _evidence_type_arrays(original):
                exported["statements"][key] = copy.deepcopy(original)
    combined = merge_manifests(exported, evidence)
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps(combined, separators=(",", ":")))
    temporary.replace(path)


def _evidence_type_arrays(statement):
    result = copy.deepcopy(statement)
    if result.get("@type") == "CredentialRegistration":
        evidence = result.get("credential", {}).get("evidence", [])
        for item in evidence if isinstance(evidence, list) else [evidence]:
            if isinstance(item, dict) and isinstance(item.get("type"), str):
                item["type"] = [item["type"]]
    return result


def install_vllm_shutdown_order():
    # vLLM 0.11 exits the engine context before awaiting HTTP shutdown.
    # Middleware construction occurs before api_server invokes serve_http.
    # Drain HTTP requests and ASGI lifespan while the GPU worker is still alive.
    api = sys.modules.get("vllm.entrypoints.openai.api_server")
    if api is None or getattr(api.serve_http, "_eqty_cuattest", False):
        return
    serve_http = api.serve_http

    async def serve_with_live_engine(*args, **kwargs):
        shutdown = await serve_http(*args, **kwargs)
        await shutdown
        async def already_stopped():
            pass
        return already_stopped()

    serve_with_live_engine._eqty_cuattest = True
    api.serve_http = serve_with_live_engine


class CuAttestEvidence:
    def __init__(self, app, config, notary_url):
        install_vllm_shutdown_order()
        self.app, self.config = app, config
        self.client = monitoring_client(notary_url, "middleware", None,
                                        config.cuattest_interval_ms)
        self.ticket = None
        self.engine = None
        self.model_cid = None

    def bind_model(self, model_cid):
        model_cid = str(model_cid)
        if self.ticket is not None and model_cid != self.model_cid:
            raise RuntimeError("cannot change the signed model while cuAttest is registered")
        self.model_cid = model_cid

    async def start(self):
        if self.ticket is not None:
            return
        if not self.model_cid:
            raise RuntimeError("cuAttest requires the signed Model CID before registration")
        self.engine = getattr(self.app.state, "engine_client", None)
        if self.engine is None or not callable(getattr(self.engine, "collective_rpc", None)):
            raise RuntimeError("cuAttest requires a vLLM engine_client with collective_rpc; "
                               "configure the cuAttest worker adapter for this NIM/vLLM backend")
        results = await self.engine.collective_rpc("eqty_cuattest_register",
                                                   kwargs={"model_cid": self.model_cid})
        if len(results) != 1 or not results[0].get("token"):
            raise RuntimeError("cuAttest middleware currently supports exactly one GPU worker")
        self.ticket = {k: results[0][k] for k in ("session", "token")}

    async def close(self):
        if self.ticket is not None:
            results = await self.engine.collective_rpc("eqty_cuattest_close")
            if len(results) != 1 or results[0].get("released") is not True:
                raise RuntimeError("cuAttest worker did not acknowledge release")
            self.ticket = None

    async def rpc(self, operation, body):
        return await asyncio.to_thread(self.client._rpc, operation, body)

    async def marker(self):
        if self.ticket is None:
            raise RuntimeError("cuAttest model is not registered")
        marker = await self.rpc("/v1/registrations/marker", self.ticket)
        if marker.get("state") != "active":
            raise RuntimeError("cuAttest model monitoring is no longer active")
        return marker

    async def probe(self):
        if self.ticket is None:
            raise RuntimeError("cuAttest model is not registered")
        return await self.rpc("/v1/registrations/samples", {
            **self.ticket, "previous": 1, "wait_ms": self.config.cuattest_wait_ms})

    async def samples(self, body):
        # The read-only token cannot mutate registrations or unload weights.
        return await self.rpc("/v1/samples", body)

    async def finish(self, marker):
        end = await self.probe()
        if not end.get("complete") or end.get("next") is None:
            raise RuntimeError("cuAttest window incomplete: no next scheduled observation")
        last = end["next"]["sequence"]
        token, expected, samples = marker["marker"], marker["sequence"], []
        while expected <= last:
            if len(samples) >= self.config.cuattest_max_samples:
                raise RuntimeError("cuAttest request window exceeds sample limit")
            page = await self.samples({"token": token, "limit": min(100, last - expected + 1, self.config.cuattest_max_samples - len(samples)), "wait_ms": 0})
            if not page["samples"]:
                raise RuntimeError("cuAttest request history is incomplete")
            for sample in page["samples"]:
                if sample["session"] != self.ticket["session"] or sample["sequence"] != expected:
                    raise RuntimeError("cuAttest history session/sequence mismatch")
                samples.append(sample)
                expected += 1
            token = page["next_token"]
        if len(samples) < 2 or samples[-1]["sequence"] != last:
            raise RuntimeError("cuAttest window must contain its previous and next observations")
        manifest = merge_manifests(*(sample["manifest"] for sample in samples))
        return {"session": self.ticket["session"], "first_sequence": marker["sequence"],
                "last_sequence": last, "complete": True,
                "sample_statement_ids": sorted({key for s in samples for key in s["receipt"]["manifest"]["statements"]}),
                "manifest": manifest}


def require_model_binding(manifest, model_cid):
    states = [s.get("credential", {}).get("credentialSubject", {}).get("state", {})
              for s in manifest.get("statements", {}).values()]
    loads = [s for s in states if s.get("stateType") == "gpuModelTensorsV1"]
    if model_cid is None or len(loads) != 1 or loads[0].get("modelCID") != str(model_cid):
        raise ValueError("cuAttest modelCID does not match the signed computation Model input")
