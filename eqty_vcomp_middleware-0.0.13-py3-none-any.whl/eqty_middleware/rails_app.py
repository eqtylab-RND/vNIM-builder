"""FastAPI adapter for :class:`eqty_middleware.rails.GuardrailRails` - the
guardrails-middleware ingress.

Wire contract:
- OpenAI-compatible ``POST /v1/chat/completions`` (streaming and buffered);
- ``X-EQTY-Request-ID`` = the exchange manifest id, resolvable via
  ``GET /integrity/manifest/{id}`` on this same ingress;
- ``X-EQTY-Guardrail: passed|blocked`` on buffered responses; a real token
  stream can't know the verdict at header time, so it sends
  ``X-EQTY-Guardrail: streaming`` and carries the outcome in-band (final
  chunk ``finish_reason: content_filter`` on a block) - the exchange manifest
  is the authoritative verdict either way;
- CORS on all responses incl. errors, OPTIONS short-circuit;
- ``/.well-known/did-registration`` -> in-guest notary; everything else is
  reverse-proxied to the model server.

Run: ``python -m eqty_middleware.rails_app`` (env below), TLS if cert/key exist.

    GUARD_POLICY_DIR        mounted NeMo policy (ConfigMap)   [/etc/eqty/policy]
    GUARD_UPSTREAM_URL      model server base                 [http://127.0.0.1:8000]
    GUARD_NOTARY_DID_URL    notary DID registration URL       [http://127.0.0.1:8066/v1/did_registration]
    EQTY_TRAINING_DID_PATH  mounted training DID registration [/etc/eqty/did/did-registration.json]
    EQTY_LOG_DIR            manifest dir                      [/proof]
    GUARD_PORT / GUARD_TLS_CERT / GUARD_TLS_KEY / GUARD_LLM_API_KEY
    GUARD_APP_TITLE         FastAPI title                     [guardrails-middleware]
    GUARD_DEFAULT_MODEL     "model" fallback when a request omits it [rails.model_name]
"""
import asyncio
import json
import logging
import os
from typing import Optional

import httpx
from fastapi import FastAPI, Request, Response
from fastapi.responses import JSONResponse, StreamingResponse

from .rails import REFUSAL_TEXT, GuardrailRails, completion_payload as _completion, sse as _sse

logger = logging.getLogger(__name__)

EQTY_HDR = "X-EQTY-Request-ID"

CORS_HEADERS = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Allow-Headers": "Authorization, Content-Type",
    "Access-Control-Expose-Headers": "X-EQTY-Request-ID, X-EQTY-Guardrail",
    "Access-Control-Max-Age": "3600",
}


def create_app(rails: GuardrailRails, server_base: str, notary_did_url: str,
               log_dir: str, title: str = "guardrails-middleware",
               default_model: Optional[str] = None) -> FastAPI:
    app = FastAPI(title=title)
    # GUARD_DEFAULT_MODEL is an override; absent that, fall back to whatever
    # model the loaded policy is actually configured for (rails.model_name).
    default_model = default_model or getattr(rails, "model_name", None) or "model"
    client = httpx.AsyncClient(timeout=600.0)

    @app.middleware("http")
    async def cors_always(request: Request, call_next):
        if request.method == "OPTIONS":
            resp = Response(status_code=204)
        else:
            resp = await call_next(request)
        for k, v in CORS_HEADERS.items():
            resp.headers[k] = v
        return resp

    @app.exception_handler(Exception)
    async def cors_on_error(request: Request, exc: Exception):
        logger.error(f"guardrails error on {request.url.path}: {exc}")
        resp = JSONResponse(
            status_code=502,
            content={"error": "guardrails_error", "detail": str(exc)[:300]},
        )
        for k, v in CORS_HEADERS.items():
            resp.headers[k] = v
        return resp

    @app.get("/health")
    async def health():
        return {
            "ok": True, "upstream": server_base, "policy_dir": rails.policy_dir,
            "log_dir": log_dir, "mode": "nemo-native-streaming",
        }

    @app.api_route("/.well-known/did-registration", methods=["GET", "POST", "OPTIONS"])
    async def did_registration(request: Request):
        body = await request.body()
        r = await client.request(
            request.method, notary_did_url, content=body or None,
            headers={"content-type": request.headers.get("content-type", "application/json")},
        )
        return Response(content=r.content, status_code=r.status_code,
                        media_type=r.headers.get("content-type", "application/json"))

    @app.post("/v1/chat/completions")
    async def chat(request: Request):
        raw = await request.body()
        try:
            body = json.loads(raw)
            messages = body["messages"]
        except Exception:
            return await _forward(request, raw)  # not a chat body we guard

        model = body.get("model", default_model)
        want_stream = bool(body.get("stream"))

        gen_params = {
            k: body.get(k)
            for k in ("temperature", "max_tokens", "top_p",
                      "presence_penalty", "frequency_penalty")
            if body.get(k) is not None
        }
        turn = await rails.run_turn(messages, raw, gen_params=gen_params,
                                    stream=want_stream, model=model)
        if turn.block_body is not None:
            # Input rail blocked: the model was never called. Send the exact
            # bytes attested as the input_guardrail's Delivered Response.
            headers = {EQTY_HDR: turn.exchange_id, "X-EQTY-Guardrail": "blocked"}
            logger.info(f"INPUT {turn.result} rail={turn.blocked_rail} "
                        f"manifest={turn.exchange_id}")
            if want_stream:
                body = turn.block_body

                async def gen():
                    yield body

                return StreamingResponse(gen(), media_type="text/event-stream",
                                         headers=headers)
            return Response(content=turn.block_body, media_type="application/json",
                            headers=headers)

        if want_stream:
            headers = {EQTY_HDR: turn.exchange_id, "X-EQTY-Guardrail": "streaming"}

            async def sse_gen():
                cid = f"guarded-{turn.exchange_id}"
                yield _sse({"id": cid, "object": "chat.completion.chunk", "model": model,
                            "choices": [{"index": 0, "delta": {"role": "assistant"},
                                         "finish_reason": None}]})
                async for chunk in rails.chunks(turn):
                    yield _sse({"id": cid, "object": "chat.completion.chunk",
                                "model": model,
                                "choices": [{"index": 0, "delta": {"content": chunk},
                                             "finish_reason": None}]})
                finish = "stop" if turn.result == "passed" else "content_filter"
                done = {"id": cid, "object": "chat.completion.chunk", "model": model,
                        "choices": [{"index": 0, "delta": {}, "finish_reason": finish}]}
                if turn.result != "passed":
                    done["x_guardrail"] = {
                        "blocked": True, "stage": "output",
                        "rail": turn.blocked_rail,
                        "manifest_id": turn.exchange_id,
                        **{k: turn.output_verdict[k]
                           for k in ("delivered_chunks", "delivered_bytes")
                           if k in (turn.output_verdict or {})},
                    }
                yield _sse(done)
                yield "data: [DONE]\n\n"
                logger.info(f"STREAMED turn={turn.result} manifest={turn.exchange_id}")

            return StreamingResponse(sse_gen(), media_type="text/event-stream",
                                     headers=headers)

        # Buffered client: same NeMo streaming path internally, accumulated.
        async for _ in rails.chunks(turn):
            pass
        if turn.result == "passed":
            headers = {EQTY_HDR: turn.exchange_id, "X-EQTY-Guardrail": "passed"}
            payload = _completion(model, turn.delivered_text, "stop", turn.exchange_id)
        else:
            rail = turn.blocked_rail or "output"
            headers = {EQTY_HDR: turn.exchange_id, "X-EQTY-Guardrail": "blocked"}
            payload = _completion(
                model, REFUSAL_TEXT, "content_filter", turn.exchange_id,
                {"blocked": True, "stage": "output", "rail": rail,
                 "reason": turn.output_verdict.get("reason", "blocked by output rail"),
                 "manifest_id": turn.exchange_id},
            )
        logger.info(f"BUFFERED turn={turn.result} manifest={turn.exchange_id}")
        return JSONResponse(payload, headers=headers)

    @app.get("/integrity/manifest/{request_id}")
    @app.get("/integrity/logs/{request_id}")
    async def integrity(request_id: str, request: Request):
        suffix = ".manifest.json" if "/manifest/" in request.url.path else ".json"
        local = os.path.join(log_dir, f"{os.path.basename(request_id)}{suffix}")
        if os.path.isfile(local):
            with open(local, "rb") as f:
                return Response(content=f.read(), media_type="application/json")
        return await _forward(request, b"")

    @app.api_route("/{full_path:path}",
                   methods=["GET", "POST", "PUT", "DELETE", "OPTIONS", "HEAD"])
    async def passthrough(full_path: str, request: Request):
        raw = await request.body()
        return await _forward(request, raw, path="/" + full_path)

    async def _forward(request: Request, raw: bytes, path: str = None):
        url = server_base + (path or request.url.path)
        if request.url.query:
            url += "?" + request.url.query
        fwd = {k: v for k, v in request.headers.items()
               if k.lower() not in ("host", "content-length", "connection",
                                    "accept-encoding")}
        r = await client.request(request.method, url, content=raw or None, headers=fwd)
        resp_headers = {k: v for k, v in r.headers.items()
                        if k.lower() not in ("transfer-encoding", "connection",
                                             "content-length", "content-encoding")}
        return Response(content=r.content, status_code=r.status_code,
                        headers=resp_headers, media_type=r.headers.get("content-type"))

    @app.on_event("shutdown")
    async def _drain():
        await asyncio.to_thread(rails.drain)

    return app


def main():
    logging.basicConfig(level=logging.INFO)
    policy_dir = os.environ.get("GUARD_POLICY_DIR", "/etc/eqty/policy")
    server_base = os.environ.get("GUARD_UPSTREAM_URL", "http://127.0.0.1:8000").rstrip("/")
    if server_base.endswith("/v1"):
        server_base = server_base[: -len("/v1")]
    notary_did_url = os.environ.get(
        "GUARD_NOTARY_DID_URL", "http://127.0.0.1:8066/v1/did_registration"
    )
    training_did = os.environ.get(
        "EQTY_TRAINING_DID_PATH", "/etc/eqty/did/did-registration.json"
    )
    log_dir = os.environ.get("EQTY_LOG_DIR", "/proof")
    port = int(os.environ.get("GUARD_PORT", "40443"))
    tls_cert = os.environ.get("GUARD_TLS_CERT", "/etc/tls/tls.crt")
    tls_key = os.environ.get("GUARD_TLS_KEY", "/etc/tls/tls.key")
    os.environ.setdefault("OPENAI_API_KEY", os.environ.get("GUARD_LLM_API_KEY", "any"))

    rails = GuardrailRails(
        policy_dir=policy_dir,
        log_directory=log_dir,
        server_base=server_base,
        notary_did_url=notary_did_url,
        training_did_path=training_did,
    )
    app = create_app(
        rails, server_base, notary_did_url, log_dir,
        title=os.environ.get("GUARD_APP_TITLE", "guardrails-middleware"),
        default_model=os.environ.get("GUARD_DEFAULT_MODEL"),
    )

    import uvicorn
    kwargs = {"host": "0.0.0.0", "port": port, "log_level": "info"}
    if os.path.exists(tls_cert) and os.path.exists(tls_key):
        kwargs.update(ssl_certfile=tls_cert, ssl_keyfile=tls_key)
    logger.info(
        f"guardrails-middleware :{port} {'TLS' if 'ssl_certfile' in kwargs else 'plain'}"
        f" -> {server_base} | policy={policy_dir} | manifests->{log_dir}"
    )
    uvicorn.run(app, **kwargs)


if __name__ == "__main__":
    main()
