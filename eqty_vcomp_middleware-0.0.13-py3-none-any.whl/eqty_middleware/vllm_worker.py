"""vLLM worker-extension hook. Loaded only when explicitly configured.

Use --worker-extension-cls eqty_middleware.vllm_worker.CuAttestWorkerExtension.
The owning worker retains cuAttest's RegisteredModel until matching close ACK.
"""
import logging
import os
import time

logger = logging.getLogger(__name__)


class CuAttestWorkerExtension:
    def eqty_cuattest_register(self, model_cid):
        # Use vLLM's configured worker logger (workers start in fresh processes).
        global logger
        import sys
        if "vllm.logger" in sys.modules:
            logger = sys.modules["vllm.logger"].init_logger(__name__)
        from .config import Config
        from .cuattest import monitoring_client
        config = Config.from_env()
        if not config.enable_cuattest:
            raise RuntimeError("EQTY_CUATTEST is not enabled")
        if getattr(self, "_eqty_cuattest_lease", None) is not None:
            if model_cid != self._eqty_cuattest_model_cid:
                raise RuntimeError("cuAttest registration belongs to a different signed model")
            lease = self._eqty_cuattest_lease
            return {"session": lease.session, "token": lease.token}
        parallel = self.parallel_config
        if any(getattr(parallel, key, 1) != 1 for key in
               ("tensor_parallel_size", "pipeline_parallel_size", "data_parallel_size")):
            raise RuntimeError("cuAttest supports single-GPU TP=PP=DP=1 only")
        if getattr(self.model_config, "enable_sleep_mode", False):
            raise RuntimeError("cuAttest cannot register vLLM sleep/VMM allocations")
        if getattr(self.cache_config, "cpu_offload_gb", 0):
            raise RuntimeError("cuAttest requires all weights to remain on GPU")
        if getattr(self, "lora_config", None) or getattr(self, "speculative_config", None):
            raise RuntimeError("cuAttest adapter currently supports a fixed base model only")
        if not isinstance(model_cid, str) or not model_cid.startswith("urn:cid:"):
            raise RuntimeError("cuAttest requires the signed Model CID from middleware")
        url = config.cuattest_url or os.getenv("EQTY_NOTARY_URL", "http://127.0.0.1:8066")
        # Use the same model asset CID that the middleware signs as a compute input.
        client = monitoring_client(url, "vllm-base-model", model_cid, config.cuattest_interval_ms)
        import torch
        model = self.model_runner.model
        state = model.state_dict()
        if any(t.numel() and not t.is_cuda for t in state.values()):
            raise RuntimeError("cuAttest cannot silently omit CPU-resident model state")
        torch.cuda.synchronize()
        try:
            self._eqty_cuattest_lease = client.register_model(model)
        except BaseException:
            # Upstream retains uncertain registrations. Retire them before any
            # caller is allowed to tear down this process or model storage.
            for lease in client.registrations():
                self._eqty_cuattest_lease = lease
                self.eqty_cuattest_close()
            raise
        self._eqty_cuattest_model_cid = model_cid
        original_shutdown = self.shutdown

        def shutdown(*args, **kwargs):
            self.eqty_cuattest_close()
            return original_shutdown(*args, **kwargs)

        self.shutdown = shutdown
        # Keep registered base weights immutable; explicit shutdown closes first.
        for name in ("sleep", "wake_up", "reload_weights", "load_model", "update_config",
                     "reinitialize_distributed", "add_lora", "remove_lora"):
            if hasattr(self, name):
                original = getattr(self, name)

                def guarded(*args, _original=original, **kwargs):
                    if getattr(self, "_eqty_cuattest_lease", None) is not None:
                        raise RuntimeError("unload the cuAttest registration before changing model storage")
                    return _original(*args, **kwargs)

                setattr(self, name, guarded)
        lease = self._eqty_cuattest_lease
        logger.info("cuAttest registered resident model; session=%s", lease.session)
        return {"session": lease.session, "token": lease.token}

    def eqty_cuattest_close(self):
        lease = getattr(self, "_eqty_cuattest_lease", None)
        if lease is None:
            return {"released": True}
        while True:
            try:
                lease.close()
                self._eqty_cuattest_lease = None
                logger.info("cuAttest unload acknowledged; model storage can be released")
                return {"released": True}
            except Exception as error:
                # Never authorize worker/model teardown on an ambiguous response.
                logger.error("cuAttest close uncertain; retaining GPU storage and retrying: %s", error)
                time.sleep(1)
