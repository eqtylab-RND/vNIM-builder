import logging
from functools import wraps
from typing import Any, Callable, Dict, Optional

from eqty_sdk._rust import Context

from . import Compute

logger = logging.getLogger("eqty.sdk.decorator")


def compute(
    metadata: Optional[Dict[str, Any]] = None,
    ctx: Optional[Context] = None,
    _store: Optional[bool] = None,
    **compute_kwargs,
):
    def decorator(func: Callable):
        @wraps(func)
        def wrapper(*args, **kwargs):
            compute_asset = Compute(func, metadata, _store, ctx, **compute_kwargs)
            result = compute_asset.__call__(*args, **kwargs)

            return result

        return wrapper

    return decorator
