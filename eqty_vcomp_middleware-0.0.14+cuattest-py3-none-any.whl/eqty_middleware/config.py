import os
from dataclasses import dataclass


@dataclass(frozen=True)
class Config:
    """All EQTY_* tunables, read once when the middleware is constructed.

    Reading env here (via :meth:`from_env`, called from ``__init__``) rather than
    at module import keeps the module importable without the environment in
    place and lets a per-worker fork change behaviour before constructing the
    middleware.
    """

    enable_cuattest: bool = False
    cuattest_url: str = ""
    cuattest_interval_ms: int = 1000
    cuattest_wait_ms: int = 30000
    cuattest_max_samples: int = 10000

    def __post_init__(self):
        if self.enable_cuattest:
            if not 1000 <= self.cuattest_interval_ms <= 86400000:
                raise ValueError("cuAttest interval must be 1000..86400000 ms")
            if not 1 <= self.cuattest_wait_ms <= 30000:
                raise ValueError("cuAttest wait must be 1..30000 ms")
            if self.cuattest_max_samples < 2:
                raise ValueError("cuAttest windows require at least two samples")

    debug: bool = False
    # Per-side header capture, opt-in: headers are dropped from the manifest by
    # default. Replaces the single, inverted EQTY_MIDDLEWARE_NOHEADERHASH.
    include_request_header: bool = False
    include_response_header: bool = False
    # CoSAI per-model signing signatures (SECP256R1 keys only); on by default.
    enable_cosai: bool = True
    # Body capture representation. json_body=False (default) stores the body as
    # base64 of the *exact wire bytes*, so the CID binds what was actually
    # transmitted with no parse/re-serialize round-trip. True parses bodies
    # (utf-8 -> JSON object, falling back to raw text / base64) before hashing,
    # which can desync the CID from the raw payload: a parsed-then-reserialized
    # JSON body no longer matches the bytes the sender sent.
    json_body: bool = False
    # isolate_body=True (default) breaks each request/response body out of the
    # Request/Response document into its OWN content-addressed node, wired into
    # the Computation as a separate input/output. Identical bodies across requests
    # then share one CID, so the lineage graph is composable on body content
    # alone. Size-only/opaque placeholders are never isolated (see manifest_writer).
    isolate_body: bool = True
    # Attest every dispatched route, including infra/health probes (legacy behavior).
    attest_all: bool = False
    # Cap the number of retained *.manifest.json files; once reached, the oldest
    # are pruned on each write (base_model is never pruned). This is the
    # workload-agnostic bound on /tmp/api_logs growth - it holds on any app
    # regardless of which paths are excluded. 0 = unlimited.
    log_max_files: int = 1000
    # Seconds to spend draining pending attestation writes on graceful shutdown.
    drain_timeout: float = 25.0
    # Largest request/response body (bytes) captured verbatim into a manifest;
    # over this a size-only placeholder is stored so a huge upload/generation
    # can't OOM the worker. Default is far above real LLM I/O (KBs),
    # so normal attestation content is unaffected. 0 disables the cap.
    max_body_bytes: int = 25 * 1024 * 1024
    # SDK working dir; was hardcoded to /tmp/EQTYSDK.
    sdk_home: str = "/tmp/EQTYSDK"
    # Operator paths to exclude from attestation: each is an exact path or a
    # trailing-'*' prefix (e.g. "/v1/health/*"). The middleware hardcodes only
    # its own routes; the wrapped server's infra/probe paths are declared here.
    exclude_paths: frozenset = frozenset()

    @classmethod
    def from_env(cls) -> "Config":
        def _b(name: str, default: str = "false") -> bool:
            return os.getenv(name, default).lower() == "true"

        # ENABLE_COSAI is the canonical name (default true). USE_COSAI / USE_COSIA
        # (the latter a historical typo) are the prior names, kept only for
        # back-compat and honored when the new var is unset; they will be removed
        # soon - migrate deployments to ENABLE_COSAI.
        cosai = os.getenv("EQTY_MIDDLEWARE_ENABLE_COSAI")
        if cosai is None:
            cosai = os.getenv("EQTY_MIDDLEWARE_USE_COSAI") or os.getenv(
                "EQTY_MIDDLEWARE_USE_COSIA"
            )

        return cls(
            enable_cuattest=_b("EQTY_CUATTEST"),
            cuattest_url=os.getenv("EQTY_MIDDLEWARE_CUATTEST_URL", ""),
            cuattest_interval_ms=int(os.getenv("EQTY_MIDDLEWARE_CUATTEST_INTERVAL_MS", "1000")),
            cuattest_wait_ms=int(os.getenv("EQTY_MIDDLEWARE_CUATTEST_WAIT_MS", "30000")),
            cuattest_max_samples=int(os.getenv("EQTY_MIDDLEWARE_CUATTEST_MAX_SAMPLES", "10000")),
            debug=_b("EQTY_DEBUG"),
            include_request_header=_b("EQTY_MIDDLEWARE_INCLUDE_REQUEST_HEADER"),
            include_response_header=_b("EQTY_MIDDLEWARE_INCLUDE_RESPONSE_HEADER"),
            enable_cosai=(cosai or "true").lower() == "true",
            json_body=_b("EQTY_MIDDLEWARE_JSON_BODY", "false"),
            isolate_body=_b("EQTY_MIDDLEWARE_ISOLATE_BODY", "true"),
            attest_all=_b("EQTY_MIDDLEWARE_ATTEST_ALL"),
            log_max_files=int(os.getenv("EQTY_MIDDLEWARE_LOG_MAX_FILES", "1000") or "1000"),
            drain_timeout=float(os.getenv("EQTY_MIDDLEWARE_DRAIN_TIMEOUT", "25") or 25),
            max_body_bytes=int(
                os.getenv("EQTY_MIDDLEWARE_MAX_BODY_BYTES", str(25 * 1024 * 1024)) or 0
            ),
            sdk_home=os.getenv("EQTY_SDK_HOME", "/tmp/EQTYSDK"),
            exclude_paths=frozenset(
                p.strip()
                for p in os.getenv("EQTY_MIDDLEWARE_EXCLUDE_PATHS", "").split(",")
                if p.strip()
            ),
        )
